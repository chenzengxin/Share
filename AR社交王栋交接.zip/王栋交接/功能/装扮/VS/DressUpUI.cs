﻿using LitJson;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

using ND.Game.BusinessFramework;
using ND.ARGame.Data;
using ND.ARGame.Login;
using ND.ARGame.Net;
using ND.ARGame.Define;
using ND.ARGame.Config;

namespace ND.Game.UILogic
{
    public class DressUpUI : UIMonoSingleton<DressUpUI>
    {
        private const string BoardUIPath = "UI/Prefabs/DressUp/DressUpUI_board";
        private const string CellUIPath = "UI/Prefabs/DressUp/DressUpUI_cell";
        private const string TipUIPath = "UI/Prefabs/DressUp/DressUpUI_tip";
        private const string DressUpIconResPath = "UI/Icon/DressUpIcon/";

        private static int[] iconPosArray = new int[] { 1, 2, 4, 3, 0 };
        private static Color ShadowColor = new Color(0f, 0f, 0f, 100f / 255);

        private CultivatePet currentPetData;
        private Transform content;
        private List<Sprite> buildingIconList = new List<Sprite>();

        public override void OnInit()
        {
            content = UnityHelper.FindTheChildNode(transform, "MainPanel/ScrollRect/Viewport/Content");
            RigisterButtonObjectEvent("MainPanel/CloseButton", (go) => { CloseUIForm(); });

            for (int i = 1; i <=DressUpUIData.TotalBuildingNum * DressUpUIData.TotalLevel ; i++)
            {
                LoadBundleResMgr.Instance.LoadAssetbund<Sprite>(NResourceType.ICON, DressUpIconResPath+i.ToString(), iconRes =>
                {
                    buildingIconList.Add(iconRes);
                });
            }
        }

        public override void RedisplayInit()
        {
            EventCenter.AddListener<string>(MsgEventType.UPGRADE_PET_PART, UpgradePetPartCallBack);

            Dictionary<string, CultivatePet> thDic = Player.instance.GetPlayerInfo().petDictionary;
            string curThId = Player.instance.GetPlayerInfo().CurrentCultivatePetId;
            currentPetData = thDic[curThId];

            InitContent();
        }

        public override void OnAfterHide()
        {
            EventCenter.RemoveListener<string>(MsgEventType.UPGRADE_PET_PART, UpgradePetPartCallBack);

            for (int i = 0; i < content.childCount; i++)
            {
                UnityHelper.Destroy(content.GetChild(i).gameObject);
            }
        }


        private void InitContent()
        {
            for (int i = 0; i < iconPosArray.Length;i++ )
            {
                LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.UI, BoardUIPath, boardRes =>
                {
                    LoadBundleResMgr.Instance.LoadAssetbund<Sprite>(NResourceType.ICON, DressUpIconResPath + "title_" + (i + 1).ToString(), titleRes =>
                    {
                        GameObject board = UnityHelper.CreateUIObject(content, boardRes);
                        Transform boardContent = UnityHelper.FindTheChildNode(board.transform, "GridLayout");
                        Transform boardTitle = UnityHelper.FindTheChildNode(board.transform, "Title");
                        boardTitle.GetComponent<Image>().sprite = titleRes;
                        InstantiateCell(boardContent, iconPosArray[i]);
                    });
                });
            }
        }

        private void InstantiateCell(Transform content, int buildingNum)
        {
            for (int j = 0; j < DressUpUIData.TotalLevel; j++)
            {
                LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.UI, CellUIPath, cellRes =>
                {
                    GameObject cell = UnityHelper.CreateUIObject(content, cellRes);
 
                    Transform icon = UnityHelper.FindTheChildNode(cell.transform, "Icon");
                    Transform money = UnityHelper.FindTheChildNode(cell.transform, "Money");
                    Transform isDressable = UnityHelper.FindTheChildNode(cell.transform, "IsDressable");
                    Transform isCompleted = UnityHelper.FindTheChildNode(cell.transform, "IsCompleted");

                    string Id = currentPetData.petIndex.ToString() + (buildingNum + 1).ToString() + (j + 1).ToString();
                    long coin = DressUpConfigMgr.instance.GetConfig(Id).Coin;

                    money.GetComponent<Text>().text = coin.ToString();
                    icon.name = buildingNum + "_" + buildingNum + "_" + j;
                    icon.GetComponent<Button>().interactable = false;
                    isCompleted.gameObject.SetActive(false);
                    isDressable.gameObject.SetActive(false);

                    if (j <= currentPetData.bodyPartDictionary[buildingNum+1].bodyPartLevel)
                    {
                        if (j < currentPetData.bodyPartDictionary[buildingNum+1].bodyPartLevel)
                        {
                            money.gameObject.SetActive(false);                 
                            isCompleted.gameObject.SetActive(true);
                        }
                        else
                        {
                            icon.GetComponent<Button>().interactable = true;
                            RigisterButtonObjectEvent(icon, OnItemCellClick);

                            if (Player.instance.GetPlayerInfo().CoinCount < coin || currentPetData.bodyPartDictionary[buildingNum + 1].bodyPartStatus == 1)
                            {
                                money.GetComponent<Text>().color = Color.red;
                            }
                            else
                            {
                                isDressable.gameObject.SetActive(true);
                            }
                        }
                    }
                    else
                    {
                        icon.GetComponent<Image>().color = ShadowColor;
                    }

                    icon.GetComponent<Image>().sprite = buildingIconList[buildingNum*DressUpUIData.TotalBuildingNum+j];
                });
            }
        }

        private void OnItemCellClick(GameObject go)
        {
            string[] data = go.name.Split('_');
            DressUpUIData.buildingId =int.Parse(data[0]);
            DressUpUIData.buildingNum = int.Parse(data[1]);
            DressUpUIData.level=int.Parse(data[2]);

            RequestUpgradePetPart();
        }

        private void Dress(int part,int level,long coin,int isComplete,int star)
        {
            BodyPart building = currentPetData.bodyPartDictionary[part];

            // 同步数据
            currentPetData.iSComplete = isComplete;
            currentPetData.bodyPartDictionary[part].bodyPartLevel = level;
            Player.instance.GetPlayerInfo().CoinCount = coin;
            Player.instance.GetPlayerInfo().StartCount = star;          

            // 改变显示
            MainSceneInit.instance.UpgradePart(building, currentPetData);

            // 弹出气泡
            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.UI, TipUIPath, tipRes =>
            {
                GameObject tip = UnityHelper.CreateUIObject(PetCultivateUI.Instance.transform, tipRes);
                tip.GetComponent<RectTransform>().localPosition = new Vector3(120, 435);
                GameObject.Destroy(tip, 2);
            });

            // 播放音效
            SoundManager.Instance.PlaySound(SoundType.Effect, SoundPlayType.Only, "UI_Audio/dressUp_complete");

            if (level == 5)
            {
                NWarningManager.Instance.OpenPromptPanel("恭喜您，完成该部位的装扮", 2);
            }

            int fullLevelNum = 0;
            foreach (var data in currentPetData.bodyPartDictionary)
            {
                if (data.Value.bodyPartLevel == 5)
                {
                    fullLevelNum++;
                }
            }

            if (isComplete == 1||fullLevelNum == DressUpUIData.TotalBuildingNum)
            {
                OpenUIForm("DressUp/DressUpPassUI", UIFormType.Switch, UIFormShowMode.Overlay);
            }

            // 关闭UI
            CloseUIForm();
        }


        #region 网络事件

        /// <summary>
        /// 请求 升级部件
        /// </summary>
        private void RequestUpgradePetPart()
        {
            JsonData data = new JsonData();
            data["part"] = DressUpUIData.buildingNum + 1;
            NetManager.instance.Request(MsgEventType.UPGRADE_PET_PART, data.ToJson());
        }

        /// <summary>
        /// 升级部件 回调
        /// </summary>
        /// <param name="message">消息</param>
        private void UpgradePetPartCallBack(string message)
        {
            Debug.Log(message);
            JsonData data = JsonMapper.ToObject(message);

            if (message != string.Empty && message.Contains("err_msg"))
            {
                string err_msg = data["err_msg"].ToJson().Replace("\"", "");
                NWarningManager.Instance.OpenErrorCode(err_msg, 2);
            }
            else
            {
                int part = int.Parse(data["part"].ToJson().Replace("\"", ""));
                int level = int.Parse(data["level"].ToJson().Replace("\"", ""));
                long coin = long.Parse(data["coin"].ToJson().Replace("\"", ""));
                int is_complete = int.Parse(data["is_complete"].ToJson().Replace("\"", ""));
                int star = int.Parse(data["star"].ToJson().Replace("\"", ""));

                Dress(part, level, coin, is_complete, star);
            }
        }

        #endregion
    }
}
