﻿using System;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

using ND.Game.BusinessFramework;
using ND.ARGame.Login;
using ND.ARGame.Data;
using cn.sharesdk.unity3d;

namespace ND.Game.UILogic
{
    public class DressUpPassUI : UIMonoSingleton<DressUpPassUI>
    {
        private const string IconResPath = "UI/Icon/MonsterIcon/";
        private string ImageSavePath;
        public override void OnInit()
        {
            ImageSavePath = Application.persistentDataPath + "/image.jpg";
            RigisterButtonObjectEvent("MainPanel/SelectOtherButton",OnSelectOtherButtonClick);
            RigisterButtonObjectEvent("MainPanel/ShareButton", OnShareButtonClick);
        }

        public override void RedisplayInit()
        {
            Transform icon = UnityHelper.FindTheChildNode(transform, "MainPanel/PetIcon");
            string key = Player.instance.GetPlayerInfo().CurrentCultivatePetId;
            int code = Player.instance.GetPlayerInfo().petDictionary[key].petCode;
            LoadBundleResMgr.Instance.LoadAssetbund<Sprite>(NResourceType.ICON, IconResPath + code.ToString(), iconRes =>
            {
                icon.GetComponent<Image>().sprite = iconRes;
            });
        }

        private void OnSelectOtherButtonClick(GameObject go)
        {
            CloseUIForm();
            PetUIData.isPassToOpenList = true;
            OpenUIForm("Pet/PetListUI", UIFormType.Switch, UIFormShowMode.Overlay); 
        }

        private void OnShareButtonClick(GameObject go)
        {
            CoroutineHelper.DoStartCoroutine(CaptureAndSave(new Rect(0, 0, Screen.width, Screen.height), delegate
            {
                ShareContent content = new ShareContent();
                //  content.SetText("这是条测试信息。");
                content.SetImagePath(ImageSavePath);
                // content.SetTitle("宠物分享");
                //content.SetUrl("http://www.nd.com.cn/");
                content.SetShareType(ContentType.Image);
                ShareSDK ssdk = transform.GetComponent<ShareSDK>();
                ssdk.ShowPlatformList(null, content, 100, 100);
            }));
        }

        IEnumerator CaptureAndSave(Rect mRect, Action callback)
        {
            yield return new WaitForEndOfFrame();

            Texture2D mTexture = new Texture2D((int)mRect.width, (int)mRect.height, TextureFormat.RGB24, true);
            mTexture.ReadPixels(mRect, 0, 0, true);
            mTexture.Apply();

            TextureUtility.ScalePoint(mTexture, mTexture.width / 2, mTexture.height / 2);
            byte[] bytes = mTexture.EncodeToJPG();
            File.WriteAllBytes(ImageSavePath, bytes);
            if (callback != null)
                callback();
        }
    }
}
