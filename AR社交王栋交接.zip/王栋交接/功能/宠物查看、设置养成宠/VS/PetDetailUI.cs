﻿using DG.Tweening;
using LitJson;
using ND.ARGame.Data;
using ND.ARGame.Define;
using ND.ARGame.Login;
using ND.ARGame.Net;
using ND.Events;
using ND.Game.BusinessFramework;
using ND.Utils;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ND.Game.UILogic
{

    public class PetDetailUI : UIMonoSingleton<PetDetailUI>
    {
        private const float MoveDistance = 2f;
        private const float TweenTime = 0.5f;
        private const float TouchFactor = 0.85f;

        private const string ModelUIPath = "UI/Prefabs/Pet/PetDetailUI_model";

        private GameObject petModelUI;
        private Transform modelRoot, cameraRoot;
        private Vector3 backUpCameraPos, backUpMousePos,startMovePoint;
        private Vector3[] backUpRootArray;

        private Tweener cameraTweener;
        private Tick tick;

        private int moveRootIndex = -1;
        private int backUpDirection = -2;
        private bool isStartingTouch;

        private enum Direction
        {
            Left=-1,Center,Right
        }

        public override void OnInit()
        {
            RigisterButtonObjectEvent("BackButton", (go) => { CloseUIForm(); });
            RigisterButtonObjectEvent("SelectButton", OnSelectButtonClick);
            RigisterButtonObjectEvent("LeftButton", (go) => { ChangePet(Direction.Left); });
            RigisterButtonObjectEvent("RightButton", (go) => { ChangePet(Direction.Right); });
        }

        public override void RedisplayInit()
        {
            EventCenter.AddListener<string>(MsgEventType.SET_CULTIVATE_PET, SetCultivatePetCallBack);

            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.MODEL, ModelUIPath, go =>
            {
                petModelUI = GameObject.Instantiate(go);
                cameraRoot = UnityHelper.FindTheChildNode(petModelUI.transform, "Camera");
                modelRoot = UnityHelper.FindTheChildNode(petModelUI.transform, "ModelRoot");

                backUpCameraPos = cameraRoot.transform.position;
                backUpRootArray = new Vector3[modelRoot.childCount];
                for (int i = 0; i < backUpRootArray.Length; i++)
                {
                    backUpRootArray[i] = modelRoot.GetChild(i).position;
                }
            });

            tick = new Tick();
            tick.AddEventListener(Ivent.TICK, HandleTouchEvent);
            tick.Start();

            PetUIData.RefreshData();
            InstantiateModel(1, Direction.Center);
            InstantiateModel(0, Direction.Left);
            InstantiateModel(2, Direction.Right);
            RefreshUI();

        }

        public override void OnAfterHide()
        {
            cameraRoot.transform.position = backUpCameraPos;

            for (int i = 0; i < modelRoot.childCount; i++)
            {
                Transform tran = modelRoot.GetChild(i);
                tran.position = backUpRootArray[i];
                GameObject.Destroy(tran.GetChild(0).gameObject);
            }
            GameObject.Destroy(petModelUI);

            tick.RemoveEventListener(Ivent.TICK, HandleTouchEvent);
            EventCenter.RemoveListener<string>(MsgEventType.SET_CULTIVATE_PET, SetCultivatePetCallBack);
        }

        #region Button和屏幕点击事件

        private void HandleTouchEvent(Ivent i)
        {
            if (cameraTweener != null && cameraTweener.IsPlaying())
            {
                return;
            }
            if (PetUIData.PetList.Count <= 1)
            {
                return;
            }
            if (EventSystem.current.currentSelectedGameObject != null)
            {
                return;
            }

            if (Input.GetMouseButtonDown(0))
            {
                isStartingTouch = true;
                backUpMousePos = Input.mousePosition;
                startMovePoint = cameraRoot.transform.position;
            }
            else if (Input.GetMouseButtonUp(0) && isStartingTouch)
            {
                isStartingTouch = false;
                float delta = Input.mousePosition.x - backUpMousePos.x;
                int direction = (int)(delta / Mathf.Abs(delta));
                float factor = 1 - Mathf.Abs(delta / Screen.width);

                if (factor < TouchFactor)
                {
                    ChangePet((Direction)direction,factor);
                }
                else
                {
                    cameraRoot.transform.DOMove(startMovePoint, TweenTime * (1 - factor), false);
                }
            }

            if (Input.GetMouseButton(0) && isStartingTouch)
            {
                float delta = Input.mousePosition.x - backUpMousePos.x;

                Vector3 target = startMovePoint;
                target.x=startMovePoint.x + MoveDistance * delta / Screen.width;
                cameraRoot.transform.position = target;
            }
        }

        private void ChangePet(Direction direction, float factor=1)
        {
            if (PetUIData.PetList.Count <= 1)
            {
                return;
            }
            if (cameraTweener != null && cameraTweener.IsPlaying())
            {
                return;
            }
            float origionX = factor == 1 ? cameraRoot.transform.position.x : startMovePoint.x;
            float target_x = origionX + (int)direction * MoveDistance;
            cameraTweener = cameraRoot.transform.DOMoveX(target_x, TweenTime * factor, false).OnComplete(() => { Refresh(direction); });
        }

        private void OnSelectButtonClick(GameObject go)
        {
            string petName = PetUIData.currentPetData.petName;
            string curPetId=Player.instance.GetPlayerInfo().CurrentCultivatePetId;

            if (curPetId != "0" && Player.instance.GetPlayerInfo().petDictionary[curPetId].iSComplete == 0) 
            {
                NWarningManager.Instance.OpenPromptPanel("每个场景只能有一个养成宠", 2);
            }
            else
            {
                NWarningManager.Instance.OpenDialogPanel("是否要养成“" + petName + "”？选择后将不可改变", () =>
                {
                    RequestSetCultivatePet();
                }, () => { });
            }
        }

        #endregion

        #region 其他方法

        private void Refresh(Direction direction)
        {
            PetUIData.currentPetData = PetUIData.PetList[GetPetIndexInList(direction)];
            UpdateMoveRootIndex((int)direction);

            Transform tran = modelRoot.GetChild(moveRootIndex);
            tran.Translate(3 * (int)direction * MoveDistance * Vector3.right);
            GameObject.Destroy(tran.GetChild(0).gameObject);

            InstantiateModel(moveRootIndex, direction);
            RefreshUI();
        }

        private void RefreshUI()
        {
            CultivatePet data = PetUIData.currentPetData;
            bool isCultivating = data.petIndex == 0 ? false : true;

            GameObject selButton = UnityHelper.FindTheChildNode(transform, "SelectButton").gameObject;
            GameObject culText = UnityHelper.FindTheChildNode(transform, "CultivatedText").gameObject;
            GameObject nameText = UnityHelper.FindTheChildNode(transform, "PetName").gameObject;

            selButton.SetActive(!isCultivating);
            culText.SetActive(isCultivating);
            culText.GetComponent<Text>().text = "这是我第" + data.petIndex + "只养成宠";
            nameText.GetComponent<Text>().text = data.petName;
        }

        private void UpdateMoveRootIndex(int direction)
        {
            if (backUpDirection != direction)
            {
                if (moveRootIndex == -1)
                {
                    moveRootIndex = direction == 1 ? 0 : 2;
                }
                backUpDirection = direction;
                return;
            }

            moveRootIndex += direction;
            moveRootIndex = moveRootIndex == 3 ? 0 : moveRootIndex;
            moveRootIndex = moveRootIndex == -1 ? 2 : moveRootIndex;      
        }

        private void InstantiateModel(int index,Direction direction)
        {
            List<CultivatePet> petList = PetUIData.PetList;

            CultivatePet curPet = petList[GetPetIndexInList(direction)];
            if (petList.Count <3 && direction != Direction.Center)
            {
                curPet.model = null;
            }

            MainSceneInit.instance.SceneInit(ref curPet);
            if (curPet.camera != null)
                curPet.camera.enabled = false;

            Transform tran = modelRoot.GetChild(index);
            curPet.model.transform.position = tran.position;
            curPet.model.transform.SetParent(tran);
        }

        private int GetPetIndexInList(Direction direction)
        {
            List<CultivatePet> petList = PetUIData.PetList;
            CultivatePet data = PetUIData.currentPetData;
            if (petList.Count <= 1)
            {
                return 0;
            }

            int index = petList.FindIndex(pet => pet.petId == data.petId);
            index += (int)direction;
            if (index == -1)
            {
                index = petList.Count - 1;
            }
            else if (index == petList.Count)
            {
                index = 0;
            }
            return index;
        }

        #endregion

        #region 网络事件

        /// <summary>
        /// 请求 设置养成宠
        /// </summary>
        private void RequestSetCultivatePet()
        {
            JsonData data = new JsonData();
            data["pet_id"] = PetUIData.currentPetData.petId;
            NetManager.instance.Request(MsgEventType.SET_CULTIVATE_PET, data.ToJson());
        }

        /// <summary>
        /// 设置养成宠 回调
        /// </summary>
        /// <param name="message">消息</param>
        private void SetCultivatePetCallBack(string message)
        {
            Debug.Log(message);
            JsonData data = JsonMapper.ToObject(message);

            if (message != string.Empty && message.Contains("err_msg"))
            {
                string err_msg = data["err_msg"].ToJson().Replace("\"", "");
                NWarningManager.Instance.OpenErrorCode(err_msg, 2);
            }
            else
            {
                int pet_idx = int.Parse(data["pet_idx"].ToJson().Replace("\"", ""));
                Player.instance.GetPlayerInfo().CurrentCultivatePetId = PetUIData.currentPetData.petId;
                Player.instance.GetPlayerInfo().petDictionary[Player.instance.GetPlayerInfo().CurrentCultivatePetId].petIndex = pet_idx;

                CloseUIFormsByName("LotteryUI");

                if (PetUIData.isPassToOpenList)
                {
                    PetUIData.isPassToOpenList = false;
                    CloseUIForm(1);
                }
                else
                {
                    CloseUIForm(0);
                    OpenUIForm("PetCultivateUI", UIFormType.Switch, UIFormShowMode.Overlay, 0);
                }
                ARGameMainUI.Instance.SetAddPetBtn(false);              
            }              
        }

        #endregion
    }
}

