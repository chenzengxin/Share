using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Linq;
using UnityEngine.SceneManagement;
using LitJson;
using ND.ARGame.Game;
using System;
using ND.ARGame.Manager;

using cn.sharesdk.unity3d;
using System.IO;
using ND.Game.BusinessFramework;
using ND.Game.GameLogic;
using ND.ARGame.Data;
using ND.ARGame.GameLogic;

namespace ND.Game.UILogic
{
    public enum TipPosition
    {
        Bottom, Center, Top
    }

    public class DetectorUI : UIMonoSingleton<DetectorUI>
    {

        #region ����
        //private Image faceMask;
        private Text tip;
        private Text timer;
        private Text energy;
        private Text nameText;
        private Text wiseCrack;
        private Slider progressbar;
        private GameObject loadingCircle;
        private GameObject rect;
        private GameObject qteBG;
        private Button btn_Exit;
        private Button btn_ChangeCamera;
        private Button btn_Confirm;
        private Button btn_Share;
        private HorizontalLayoutGroup layoutGroup;
        #endregion

        #region ����
        private string savePath;
        #endregion

        public HorizontalLayoutGroup LayoutGroup
        {
            get
            {
                return layoutGroup;
            }
        }
        public Button[] GetButtons()
        {
            return new Button[] { this.btn_Exit, this.btn_ChangeCamera, this.btn_Confirm, this.btn_Share };
        }
      
        /// <summary>
        /// ��ʼ���������
        /// </summary>
        public override void OnInit()
        {
            btn_Exit = parentTrans.FindChild("btn_Exit").GetComponent<Button>();
            btn_Exit.gameObject.SetActive(true);
            btn_ChangeCamera = parentTrans.FindChild("btn_ChangeCamera").GetComponent<Button>();
            btn_ChangeCamera.gameObject.SetActive(true);
            btn_Confirm = parentTrans.FindChild("btn_Confirm").GetComponent<Button>();
            btn_Confirm.gameObject.SetActive(false);
            btn_Share = parentTrans.FindChild("btn_Share").GetComponent<Button>();
            btn_Share.gameObject.SetActive(false);
            loadingCircle = parentTrans.FindChild("img_LoadingCircle").gameObject;
            loadingCircle.gameObject.SetActive(false);
            tip = parentTrans.FindChild("tip/text").GetComponent<Text>();
            tip.transform.parent.gameObject.SetActive(false);
            //faceMask = parentTrans.FindChild("img_FaceMask").GetComponent<Image>();
            //faceMask.gameObject.SetActive(true);
            timer = parentTrans.FindChild("timer").GetComponent<Text>();
            timer.gameObject.SetActive(false);
            nameText = parentTrans.FindChild("pnl_roleInfo/anchorBottomCenter/infoBG/name").GetComponent<Text>();
            nameText.gameObject.SetActive(false);
            progressbar = parentTrans.FindChild("qte/progressBar").GetComponent<Slider>();
            progressbar.value = 0;
            progressbar.gameObject.SetActive(false);
            layoutGroup = parentTrans.FindChild("qte/layoutGroup_Finger").GetComponent<HorizontalLayoutGroup>();
            layoutGroup.gameObject.SetActive(true);
            layoutGroup.transform.parent.gameObject.SetActive(true);
            rect = parentTrans.FindChild("rect").gameObject;
            rect.gameObject.SetActive(true);
            energy = parentTrans.FindChild("energy/text").GetComponent<Text>();
            energy.transform.parent.gameObject.SetActive(true);
            qteBG = parentTrans.FindChild("img_QteBG").gameObject;
            qteBG.transform.FindChild("Rect1").gameObject.AddComponent<AutoRotate>().speed= -0.7f;
            qteBG.transform.FindChild("Rect2").gameObject.AddComponent<AutoRotate>().speed= 0.7f;
            qteBG.transform.FindChild("Rect3").gameObject.AddComponent<AutoRotate>().speed= -0.7f;
            qteBG.gameObject.SetActive(false);
            wiseCrack = parentTrans.FindChild("pnl_roleInfo/anchorTopLeft/pnl_Talk/wisecrackText").GetComponent<Text>();
            wiseCrack.transform.parent.gameObject.SetActive(false);
            savePath = Application.persistentDataPath + "/image.jpg";
            InitEvent();
        }
        private void InitEvent()
        {
            this.btn_ChangeCamera.onClick.AddListener(OnChangeCameraClick);
            this.btn_Exit.onClick.AddListener(OnExitBtnClick);
            this.btn_Confirm.onClick.AddListener(OnConfirmBtnClick);
            this.btn_Share.onClick.AddListener(OnShareBtnClick);
        }

        public void UpdateTimer(float leftTime)
        {
            this.timer.text = leftTime + "";
        }

        public void UpdateQTE(float value)
        {
            this.progressbar.value = value;
        }

        //public void SetFaceMaskShow(bool value)
        //{
        //    switch (value)
        //    {
        //        case true:
        //            CoroutineHelper.DoStartCoroutine(TweenColor(faceMask.color, Vector4.one * 0.4f, 2));
        //            break;
        //        case false:
        //            CoroutineHelper.DoStartCoroutine(TweenColor(faceMask.color, Vector4.zero, 2));
        //            break;
        //    }
        //}
        
        public void CloseAllUI(bool isClosed)
        {
            btn_Exit.gameObject.SetActive(!isClosed);
            btn_ChangeCamera.gameObject.SetActive(!isClosed);
            energy.transform.parent.gameObject.SetActive(!isClosed);
        }

        //IEnumerator TweenColor(Color from, Color to, float time)
        //{
        //    float start = Time.time;
        //    while (start + time > Time.time)
        //    {
        //        faceMask.color = Color.Lerp(from, to, (Time.time - start) / time);
        //        yield return Time.deltaTime;
        //    }
        //}
        
        void HideGameObject(GameObject obj)
        {
            if (obj)
                obj.SetActive(false);
        }
        
        public void SetRectState(bool value)
        {
            rect.gameObject.SetActive(value);
        }
        
        public void ShowCircle(bool show)
        {
            loadingCircle.SetActive(show);
        }
        
        public void SetDefault()
        {
            this.progressbar.gameObject.SetActive(false);
            this.rect.gameObject.SetActive(false);
            this.timer.gameObject.SetActive(false);
            //this.layoutGroup.gameObject.SetActive(false);
            this.btn_Exit.gameObject.SetActive(false);
            this.btn_ChangeCamera.gameObject.SetActive(false);
            this.energy.transform.parent.gameObject.SetActive(false);
            this.qteBG.gameObject.SetActive(false);
        }
      
        public void SetInitView() {
            this.rect.gameObject.SetActive(true);
            //this.SetFaceMaskShow(true);
            this.btn_Exit.gameObject.SetActive(true);
            this.btn_ChangeCamera.gameObject.SetActive(true);
            this.energy.transform.parent.gameObject.SetActive(true);
            SetFingerView(null);
            this.timer.gameObject.SetActive(false);
            //this.layoutGroup.gameObject.SetActive(false);
            this.progressbar.gameObject.SetActive(false);
            this.tip.transform.parent.gameObject.SetActive(false);
            this.nameText.gameObject.SetActive(false);
            this.qteBG.gameObject.SetActive(false);
            this.wiseCrack.transform.parent.gameObject.SetActive(false);
            this.btn_Share.gameObject.SetActive(false);
            this.btn_Confirm.gameObject.SetActive(false);
        }
        
        public void ShowQTEBG(bool value)
        {
            this.qteBG.gameObject.SetActive(value);
        }
        
        public void ShowProgressBar(bool value)
        {
            this.progressbar.gameObject.SetActive(value);
        }
        
        /// <summary>
        /// ��ʾ��ʾ����
        /// </summary>
        /// <param name="contents"></param>
        /// <param name="position"></param>
        /// <param name="duration"></param>
        public void ShowTip(string contents, TipPosition position, float duration)
        {
            #region ����λ��
            switch (position)
            {
                case TipPosition.Top:
                    this.tip.rectTransform.parent.GetComponent<RectTransform>().anchoredPosition = new Vector3(2, 1050, 0);
                    break;
                case TipPosition.Center:
                    this.tip.rectTransform.parent.GetComponent<RectTransform>().anchoredPosition = new Vector3(2, 640, 0);
                    break;
                case TipPosition.Bottom:
                    this.tip.rectTransform.parent.GetComponent<RectTransform>().anchoredPosition = new Vector3(2, 179.5f, 0);
                    break;
                default:
                    break;
            }
            #endregion
            this.tip.transform.parent.gameObject.SetActive(true);
            this.tip.text = contents;
            CoroutineHelper.DoStartCoroutine(DelayWork(HideGameObject, tip.transform.parent.gameObject, duration));
        }
      
        /// <summary>
        /// ��ʾ��ָ���View
        /// </summary>
        /// <param name="fingerQueue"></param>
        public void SetFingerView(FingerQueue fingerQueue)
        {
            if (layoutGroup.transform.childCount > 0)
            {
                for (int i = 0; i < layoutGroup.transform.childCount; i++)
                {
                    UnityEngine.Object.Destroy(layoutGroup.transform.GetChild(i).gameObject);
                }
            }
            if (fingerQueue == null)
            {
                return;
            }
            foreach (var item in fingerQueue.queue)
            {
                item.view.transform.SetParent(layoutGroup.transform);
                item.view.transform.localScale = Vector3.one;
                item.view.transform.localPosition = Vector3.zero;
            }
        }
      
        IEnumerator DelayWork(Action<GameObject> action, GameObject obj, float delay)
        {
            yield return new WaitForSeconds(delay);
            if (action != null)
                action(obj);
        }
        
        public void ShowTimer(bool value)
        {
            this.timer.gameObject.SetActive(value);
        }
        public Text GetTimer() {
            return this.timer;
        }
        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="v"></param>
        public void SetEnergy(string v)
        {
            this.energy.text = "+" + v;
        }
        /// <summary>
        /// ��׽�ɹ������ó�����Ϣ
        /// </summary>
        /// <param name="name"></param>
        /// <param name="murmur"></param>
        public void RefreshUIInfo(string name, string murmur)
        {
            this.nameText.gameObject.SetActive(true);
            this.wiseCrack.transform.parent.gameObject.SetActive(true);
            this.btn_Share.gameObject.SetActive(true);
            this.btn_Confirm.gameObject.SetActive(true);

            this.nameText.text = name;
            this.wiseCrack.text = murmur;
        }

        public void RefreshUIInfo(CultivatePet pet)
        {
            TouchManager.instance.Init(pet);
            //this.btn_Exit.gameObject.SetActive(true);
            this.btn_Confirm.gameObject.SetActive(true);
            this.btn_Share.gameObject.SetActive(true);
            if (!string.IsNullOrEmpty(pet.petName))
            {
                this.nameText.gameObject.SetActive(true);
                this.nameText.text = pet.petName;
            }
        }

        public void OpenCaptureUIForm(string name)
        {
            OpenUIForm(name, UIFormType.Switch, UIFormShowMode.Overlay);
        }

        #region Button Event
        void OnExitBtnClick()
        {
            CoroutineHelper.DoStopAllCoroutine();
            CloseUIForm();
            //ND.Game.BusinessFramework.UIManager.Instance.CloseAllUIPanel();
            DetectorMonstersMgr.instance.OnExit();
            SceneLoadManager.Instance.LoadSceneAsync("GameMain");
        }
        void OnChangeCameraClick()
        {
            CameraHandler.instance.IsFrontFacing = !CameraHandler.instance.IsFrontFacing;
            CameraHandler.instance.SelectCamera(CameraHandler.instance.IsFrontFacing);
        }
        void OnConfirmBtnClick()
        {
            CoroutineHelper.DoStopAllCoroutine();
            UIMgr.instance.CloseAllVisibleUI();
            TouchManager.instance.Release();
            DetectorMonstersMgr.instance.OnExit();
            SceneLoadManager.Instance.LoadSceneAsync("GameMain");
        }
        void OnShareBtnClick()
        {
            //btn_Share.gameObject.SetActive(false);
            //btn_Confirm.gameObject.SetActive(false);
            //CoroutineHelper.DoStartCoroutine(CaptureAndSave(new UnityEngine.Rect(0, 0, Screen.width, Screen.height), savePath, delegate
            //{
            //    btn_Share.gameObject.SetActive(true);
            //    btn_Confirm.gameObject.SetActive(true);
            //    //CallAndroid("������99U����", savePath);

            //    ShareContent content = new ShareContent();
            //  //  content.SetText("������������Ϣ��");
            //    content.SetImagePath(savePath);
            //   // content.SetTitle("�������");
            //    //content.SetUrl("http://www.nd.com.cn/");
            //    content.SetShareType(ContentType.Image);
            //    ShareSDK ssdk = this.GetComponent<ShareSDK>();
            //    ssdk.ShowPlatformList(null, content, 100, 100);
            //}));
            NativeShare share = new NativeShare();
            share.Share(savePath);
        }
        void CallAndroid(string context, string savePath)
        {
            try
            {
                AndroidJavaClass jc = new AndroidJavaClass("com.nd.sdp.android.arplay.UnityBridge");
                AndroidJavaObject jo = jc.CallStatic<AndroidJavaObject>("getInstance");
                AndroidJavaClass jcClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                AndroidJavaObject jcObject = jcClass.GetStatic<AndroidJavaObject>("currentActivity");
                jo.Call("goShare", context, savePath);
            }
            catch (Exception)
            {
                //WarningManager.errors.Add(new WarningModel("��������" + e.Message.ToString()));
                //Debug.Log("��������");
                PopTipsUI.instance.SetVisible(true);
            }
        }
        IEnumerator CaptureAndSave(UnityEngine.Rect mRect, string mFileName, Action callback)
        {
            yield return new WaitForEndOfFrame();

            //RenderTexture mRender = new RenderTexture((int)mRect.width, (int)mRect.height, 16);

            //mCamera.targetTexture = mRender;
            //mCamera.Render();

           // RenderTexture.active = mRender;
            Texture2D mTexture = new Texture2D((int)mRect.width, (int)mRect.height, TextureFormat.RGB24, true);
            mTexture.ReadPixels(mRect,0,0,true);
            mTexture.Apply();
            //mCamera.targetTexture = null;
           // RenderTexture.active = null;
           // GameObject.Destroy(mRender);
            //print("ѹ��ͼƬ");
            TextureUtility.ScalePoint(mTexture, mTexture.width / 2, mTexture.height / 2);
            byte[] bytes = mTexture.EncodeToJPG();
            File.WriteAllBytes(savePath, bytes);
            if (callback != null)
                callback();
        }
        #endregion
    }
}