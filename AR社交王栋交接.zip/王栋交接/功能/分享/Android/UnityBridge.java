package com.nd.arplay.unitylbs.presenter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.HandlerThread;
import android.text.TextUtils;
import android.net.Uri;
import android.widget.Toast;

import com.nd.android.smartcan.network.Method;
import com.nd.arplay.unitylbs.model.ARMessage;
import com.nd.arplay.unitylbs.model.BusinessTag;
import com.nd.arplay.unitylbs.model.lbs.UpdateLocationManager;
import com.nd.arplay.unitylbs.model.login.LoginWork;
import com.nd.arplay.unitylbs.model.login.UserInfo;
import com.nd.arplay.unitylbs.model.network.ARNetService;
import com.nd.arplay.unitylbs.model.network.NetPacket;
import com.nd.arplay.unitylbs.presenter.dispatcher.ARMessageDispatcher;
import com.nd.arplay.unitylbs.presenter.processor.IProcessor;
import com.nd.arplay.unitylbs.ui.ARUnityActivity;
import com.nd.arplay.unitylbs.ui.LBSMainActivity;
import com.nd.arplay.unitylbs.utils.DebugUtils;
import com.nd.arplay.unitylbs.utils.IcrJsonUtils;
import com.nd.arplay.unitylbs.utils.LogTag;
import com.nd.arplay.unitylbs.utils.LogUtils;
import com.nd.commplatform.NdCommplatform;
import com.nd.commplatform.NdErrorCode;
import com.nd.commplatform.NdMiscCallbackListener;
import com.nd.commplatform.entry.NdLoginStatus;
import com.nd.commplatform.mvp.view.LoginDialog;
import com.nd.commplatform.util.HttpToast;
import com.nd.smartcan.accountclient.CurrentUser;
import com.nd.smartcan.accountclient.LoginCallback;
import com.nd.smartcan.accountclient.UCManager;
import com.nd.smartcan.accountclient.core.AccountException;
import com.nd.smartcan.accountclient.core.MacToken;
import com.nd.smartcan.core.security.SecurityDelegate;
import com.unity3d.player.UnityPlayer;

import java.util.HashSet;
import java.util.Set;
import java.io.File;

import de.greenrobot.event.EventBus;

/**
 * Unity桥接层
 * Created by zyf on 2016/10/25.
 */
public class UnityBridge {
    private static final LogTag[] TAG = new LogTag[]{LogTag.UNITY};
    private Activity activity;
    private Set<Integer> mRequestIdSet = new HashSet<>();
    private final static String NET_KEY = "NetManager";
    private UserInfo userInfo;

    public String getUserInfo() {
        if (userInfo == null) {
            return "";
        }
        return IcrJsonUtils.toJson(userInfo);
    }

    public UserInfo getUserInfoBean() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    private static UnityBridge unityBridge = new UnityBridge();

    public static UnityBridge getInstance() {
        return unityBridge;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    private UnityBridge() {
        HandlerThread uploadThread = new HandlerThread("unity_thread");
        uploadThread.start();
    }

    public void create() {
        LogUtils.d(TAG, "UnityBridge create");
        ARMessageDispatcher.getInstance().registerProcessor(BusinessTag.UNITY.name(), mProcessor);
    }

    public void destroy() {
        LogUtils.d(TAG, "UnityBridge destroy");
        mRequestIdSet.clear();

        ARMessageDispatcher.getInstance().unRegisterProcessor(mProcessor);
        activity = null;
    }

    /**
     * 跳转lbs
     *
     * @param activity 窗口活动上下文
     * @param content  content 消息
     */
    public void goToLBS(Activity activity, String content) {
        Intent intent = new Intent(activity, LBSMainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);//堆栈有的时候里面取，不新建Activity
        activity.startActivity(intent);
        LogUtils.d(TAG, "goUnityActivity");
    }

    //回调回来是在消息线程
    private IProcessor mProcessor = new IProcessor() {
        @Override
        public void process(ARMessage arMessage) {
        }

        @Override
        public void netProcess(ARMessage netARMessage) {
            int requestId = netARMessage.getRequestId();
            if (requestId != 0) {
                mRequestIdSet.remove(requestId);
            }
            String functionName = netARMessage.getType();
            String json = netARMessage.getContent();
            if (TextUtils.isEmpty(functionName)) {
                return;
            }
            if (TextUtils.isEmpty(json)) {
                return;
            }
            UnityPlayer.UnitySendMessage(NET_KEY, functionName, json);
        }
    };
    //回调回来是在消息线程
    private IProcessor mLoginProcessor = new IProcessor() {
        @Override
        public void process(ARMessage arMessage) {
            if (activity != null) {
                if (BusinessTag.LOGIN_CHANGE.getTagStr().equals(arMessage.getType())) {
                    goUnityGame(activity);
                }
            }
        }

        @Override
        public void netProcess(ARMessage netARMessage) {
        }
    };

    public synchronized void onReceiveNetInfo(final ARMessage ARMessage) {
//        if (mRequestIdSet.contains(ARMessage.getRequestId())) {
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mProcessor.netProcess(ARMessage);
                }
            });
        }
//        }
    }

    public String onUnityCallback(final String functionName, final String jsonParameters) {
        LogUtils.d(TAG, "onUnityCallback functionName:" + functionName + "; jsonParameters:" + jsonParameters);
        ARMessage arMessage = new ARMessage();
        arMessage.setContent(jsonParameters);
        arMessage.setType(functionName);
        mProcessor.process(arMessage);
        return "";
    }

    public int AsyncQuery(final String functionName, final String jsonParameters) {
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (activity != null && DebugUtils.isDebug()) {
                        //Toast.makeText(activity, "functionName:" + functionName + ",jsonParameters:" + jsonParameters, Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
        ARMessage ARMessage = new ARMessage();
        ARMessage.setContent(jsonParameters);
        ARMessage.setRequestId(-1);
        Set<IProcessor> processorSet = ARMessageDispatcher.getInstance().findProcessor(ARMessage);
        if (processorSet != null) {
            ARMessageDispatcher.getInstance().process(ARMessage);
        } else {
            NetPacket netPacket = new NetPacket();
            netPacket.jsonValue = jsonParameters;
            netPacket.functionName = functionName;
            mRequestIdSet.add(netPacket.getTag());
            EventBus.getDefault().post(netPacket);
            return netPacket.getTag();
        }
        return -1;
    }

//    public void goLoginUI() {
//        if (activity == null) {
//            return;
//        }
//        Intent intent = new Intent(activity.getApplicationContext(), ARPlayNdLoginActivity.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        activity.getApplicationContext().startActivity(intent);
//        LogUtils.d(TAG, "goLoginUI");
//    }

    public void onLogOut(Context context) {
        if (activity == null && context == null) {
            return;
        }
        Context targetContext;
        if (activity == null) {
            targetContext = context;
        } else {
            targetContext = activity;
        }
        try {
            NdCommplatform.getInstance().ndLogout(NdCommplatform.LOGOUT_TO_RESET_AUTO_LOGIN_CONFIG, targetContext.getApplicationContext());//注销99登录
            UCManager.getInstance().logout(targetContext.getApplicationContext());
        } catch (Exception e) {
            LogUtils.e(TAG, "sdk 注销异常");
        }
        Intent intent = new Intent(targetContext.getApplicationContext(), ARNetService.class);
        targetContext.getApplicationContext().stopService(intent);
        UnityPlayer.UnitySendMessage(ARUnityActivity.MSG_TAG, "ndLoginOut", "{}");
        LogUtils.d(TAG, "onLogOut");
    }

    /**
     * 创建角色成功调用
     */
    public void onRoleCreated() {
        LoginWork.getLoginWork().onCreatedUpdateLoginState();
    }

    /**
     * 是否已经创建了角色
     *
     * @return 返回是否chuan
     */
    public boolean isCreatedRole() {
        return LoginWork.getLoginWork().isLoginHasRole();
    }


    public void ndLogin(final Activity activity) {
        LogUtils.d(TAG, "ndLogin");
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    NdCommplatform.getInstance().ndLogin(activity, loginProcessListener);
                }
            });
        }
    }

    private NdMiscCallbackListener.OnLoginProcessListener loginProcessListener = new NdMiscCallbackListener.OnLoginProcessListener() {

        @Override
        public void finishLoginProcess(int code) {
            LogUtils.d(TAG, "finishLoginProcess code:" + code);
            String tip = "";
            // 登录的返回码检查
            if (code == NdErrorCode.ND_COM_PLATFORM_SUCCESS) {
                String s = NdCommplatform.getInstance()
                        .getSessionId();
                if (NdCommplatform.getInstance()
                        .ndGetLoginStatus() == NdLoginStatus.AccountLogin) {// 帐号登录
//                    onGoToGameLogin(activity);
                    onUCLogin();
                    return;
                } else if (NdCommplatform.getInstance()
                        .ndGetLoginStatus() == NdLoginStatus.GuestLogin) {// 游客登录
//                    onGoToGameLogin(activity);
                    onUCLogin();
                    return;
                }
            } else if (code == NdErrorCode.ND_COM_PLATFORM_ERROR_CANCEL) {
                tip = "取消帐号登录";
                if (activity != null) {
                    //Toast.makeText(activity, tip, Toast.LENGTH_SHORT).show();
                }
                UnityPlayer.UnitySendMessage(ARUnityActivity.MSG_TAG, "ndLoginFail", "{}");
            } else {
                if (activity != null) {
                    tip = HttpToast.getErrorMsg(activity, code);
                    //Toast.makeText(activity, tip, Toast.LENGTH_SHORT).show();
                    UnityPlayer.UnitySendMessage(ARUnityActivity.MSG_TAG, "ndLoginFail", "{}");
                }
            }

        }
    };
    private LoginCallback mUCLoginCallBack = new LoginCallback() {
        @Override
        public void onSuccess(CurrentUser currentUser) {
            if (currentUser == null) {
                LogUtils.w(TAG, "LoginCallback currentUser null");
                UnityPlayer.UnitySendMessage(ARUnityActivity.MSG_TAG, "ucLoginFail", "{}");
                return;
            }
            onGoToGameLogin(activity);
        }

        @Override
        public void onCanceled() {
            LogUtils.w(TAG, "LoginCallback onCanceled");
            UnityPlayer.UnitySendMessage(ARUnityActivity.MSG_TAG, "ucLoginFail", "{}");

        }

        @Override
        public void onFailed(AccountException e) {
            LogUtils.w(TAG, "LoginCallback onFailed");
            UnityPlayer.UnitySendMessage(ARUnityActivity.MSG_TAG, "ucLoginFail", "{}");
        }
    };
    private final String orgName = "101_ar_social_game";

    private void onUCLogin() {
        String userId = NdCommplatform.getInstance().getLoginUin();
        String appId = String.valueOf(NdCommplatform.getInstance().getAppId());
        String sourcePlat = "nd99private";
        String token = NdCommplatform.getInstance().getAutoCookie();
        UCManager.getInstance().loginThirdPlatform(orgName, -1, userId, appId, sourcePlat, token, mUCLoginCallBack);
    }

    private void onGoToGameLogin(Context context) {
        if (context == null) {
            return;
        }
        LogUtils.d(TAG, "onGoToGameLogin");
        LoginWork.getLoginWork().init();
        LoginWork.getLoginWork().setContext(context.getApplicationContext());
        ARMessageDispatcher.getInstance().registerProcessor(BusinessTag.LOGIN_CHANGE.getTagStr(), mLoginProcessor);
        UserInfo userInfo = parseLoginInfo();
        UnityBridge.getInstance().setUserInfo(userInfo);
        Intent intentService = new Intent(context, ARNetService.class);
        context.getApplicationContext().startService(intentService);
    }

    private UserInfo parseLoginInfo() {
        UserInfo userInfo = new UserInfo();
        String token = NdCommplatform.getInstance().getAutoCookie();
        String nickName = NdCommplatform.getInstance().getLoginNickName();
        String userId = NdCommplatform.getInstance().getLoginUin();
        CurrentUser currentUser = UCManager.getInstance().getCurrentUser();
        String ucUserId = String.valueOf(UCManager.getInstance().getCurrentUserId());
        MacToken macToken = currentUser.getMacToken();
        String ucToken = macToken.getAccessToken();
        userInfo.setNickName(nickName);
        userInfo.setToken(token);
        userInfo.setUserId(userId);
        userInfo.setUcToken(ucToken);
        userInfo.setUcUserId(ucUserId);
        return userInfo;
    }

    private void goUnityGame(Context context) {
        if (context == null) {
            LogUtils.w(TAG, "goUnityGame异常 context为空");
            return;
        }
        if (UnityBridge.getInstance().getUserInfo() == null) {
            LogUtils.w(TAG, "goUnityGame异常 userInfo为空");
            return;
        }
        if (LoginWork.getLoginWork().isLogin()) {
            ARMessageDispatcher.getInstance().unRegisterProcessor(mLoginProcessor);
            UpdateLocationManager.getUpdateLocationManager().startUpdateLocation(context.getApplicationContext());
            LogUtils.d(TAG, "ndLogin uc Success:");
            UnityPlayer.UnitySendMessage(ARUnityActivity.MSG_TAG, "ndLoginSuccess", "{}");
        }
    }

    /**
     * 刷新token
     *
     * @return 返回结果
     */
    private boolean refreshToken(String token) {
        LogUtils.d(TAG, "refreshToken Thread:" + Thread.currentThread().getName());
        boolean result = false;
        try {
            result = UCManager.getInstance().refreshToken(token);
            if (result) {
                CurrentUser currentUser = UCManager.getInstance().getCurrentUser();
                MacToken macToken = currentUser.getMacToken();
                String ucToken = macToken.getAccessToken();
                userInfo.setUcToken(ucToken);
            }
        } catch (AccountException e) {
            result = false;
            LogUtils.d(TAG, "refreshToken AccountException");
        } finally {
            return result;
        }
    }


    /**
     * 刷新服务器时间
     *
     * @return 返回结果
     */
    private boolean updateServerTime() {
        LogUtils.d(TAG, "updateServerTime Thread:" + Thread.currentThread().getName());
        boolean result = false;
        try {
            result = UCManager.getInstance().updateServerTime();
        } catch (AccountException e) {
            result = false;
            LogUtils.d(TAG, "updateServerTime AccountException");
        } finally {
            return result;
        }
    }

    public boolean isShowingLoginDialog(Activity activity) {
        boolean isShow = LoginDialog.instance(activity).isShowing();
        return isShow;
    }

    public void closeLoginDialog(Activity activity) {
        LogUtils.d(TAG, " closeLoginDialog");
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    LoginDialog.closeDialogInstance();
                }
            });
        }
    }

    public void ShowLoginDialog(final Activity activity) {
        LogUtils.d(TAG, " ShowLoginDialog");
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                  if (isShowingLoginDialog(activity))
                      LoginDialog.instance(activity).show();
                }
            });
        }
    }
    public void HideLoginDialog(final Activity activity) {
        LogUtils.d(TAG, " HideLoginDialog");
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    LoginDialog.instance(activity).hide();
                }
            });
        }
    }

    public String getIMTokenJson(String host, String uri) {
        String tokenJson = SecurityDelegate.getInstance().calculateMACContent(Method.POST, host, uri, false);
        if (TextUtils.isEmpty(tokenJson)) {
            return "";
        }
        return tokenJson;
    }

    public void goShare(String imagePath, Activity activity){
        Intent shareIntent = new Intent();
        String title = "标题";
        String subject="主题";
        String extraText="分享";

        shareIntent.setType("*/*");
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(imagePath)));
        shareIntent.putExtra(Intent.EXTRA_TITLE, title);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        shareIntent.putExtra(Intent.EXTRA_TEXT, extraText);

        Intent intent=Intent.createChooser(shareIntent, "分享");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.getApplicationContext().startActivity(intent);
    }
}
