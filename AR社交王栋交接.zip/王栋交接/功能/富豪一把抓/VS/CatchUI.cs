﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using ND.ARGame.Data;
using ND.Events;
using ND.Game.BusinessFramework;
using ND.Game.GameLogic;
using ND.Utils;
using LitJson;
using System.Collections;
using ND.ARGame.Net;
using ND.ARGame.Define;
using ND.ARGame.Login;
using ND.ARGame.Manager;
using DG.Tweening;

namespace ND.Game.UILogic
{

    public class CatchData
    {
        public static Dictionary<string, PlayerInfo> catchPlayerDictionary = new Dictionary<string, PlayerInfo>();
        public static string richerUserId = null;

        public static bool isCompleteCatch = false;

        public static void ForTest()
        {
            CleanData();
            for(int i=1;i<=6;i++)
            {
                PlayerInfo info = new PlayerInfo();
                info.userId = i.ToString();
                info.CurrentCultivatePetId = i.ToString();
                info.CoinCount = i * 1065;
                catchPlayerDictionary.Add(info.userId, info);
            }
            richerUserId = "1";
        }

        public static void CleanData()
        {
            catchPlayerDictionary.Clear();
            richerUserId=null;
            isCompleteCatch = false;
        }
    }

    public class CatchUI : UIMonoSingleton<CatchUI>
    {
        private const int RoleCount = 17;
        private const string ModelPath = "UI/Prefabs/Catch/";

        private GameObject catchModel;
        private Transform  cameraRoot;
        private Tick tick;

        private Vector2 oldMousePosition;

        public List<GameObject> catchGoList = new List<GameObject>();

        public override void OnInit()
        {
        }

        public override void RedisplayInit()
        {
            EventCenter.AddListener<string>(MsgEventType.GET_RICH_PLAYER_LIST, GetRichPlayerListCallBack);
            NetManager.instance.Request(MsgEventType.GET_RICH_PLAYER_LIST, "");
            //UnityEngine.TextAsset s = Resources.Load("myjson") as TextAsset;
            //GetRichPlayerListCallBack(s.text);
        }

        public override void OnAfterHide()
        {
            EventCenter.RemoveListener<string>(MsgEventType.GET_RICH_PLAYER_LIST, GetRichPlayerListCallBack);
            GameObject.Destroy(catchModel);
            tick.Stop();
        }

        public void SwitchToResultPannel()
        {
            CloseUIForm();
            OpenUIForm("Catch/CatchResultUI", UIFormType.Switch, UIFormShowMode.HideOther);
        }

        private void InitCatchScene()
        {
            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.MODEL, ModelPath + "CatchModel", go =>
            {
                catchModel = GameObject.Instantiate(go);
                cameraRoot = UnityHelper.FindTheChildNode(catchModel.transform, "Camera");
                Transform modelRoot = UnityHelper.FindTheChildNode(catchModel.transform, "ModelRoot");
                foreach (var data in CatchData.catchPlayerDictionary)
                {
                    InstantiateModel(modelRoot, data.Value);
                }
            });

            RefreshTitle();

            tick = new Tick();
            tick.AddEventListener(Ivent.TICK, HandleTouchEvent);
            tick.Start();
        }

        private void HandleTouchEvent(Ivent i)
        {
            if (Input.GetMouseButtonDown(0))
            {
                oldMousePosition = Input.mousePosition;
            }

            if (Input.GetMouseButtonUp(0))
            {
                Vector2 delta = (Vector2)Input.mousePosition - oldMousePosition;
                Debug.Log("delta:" + delta.magnitude);
                if (delta.magnitude < 15)
                {
                    Ray ray = cameraRoot.GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);
                    RaycastHit info;
                    if (Physics.Raycast(ray, out info))
                    {
                        if (info.transform.GetComponent<CatchPlayerController>() != null)
                        {
                            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.MODEL, ModelPath + "CatchRope", go =>
                            {
                                GameObject rope = GameObject.Instantiate(go) as GameObject;
                                rope.transform.position = cameraRoot.GetComponent<Camera>().ScreenToWorldPoint(Input.mousePosition);
                                rope.transform.SetParent(catchModel.transform);
                                CatchRope script = rope.AddComponent<CatchRope>();
                                script.target = info.transform;
                            });
                        }
                    }
                }
            }
        }


        private void RefreshTitle()
        {
            Image icon = UnityHelper.FindTheChildNode(transform,"Top/AttackedIcon/IconMask/Icon").GetComponent<Image>();
            Text starValue = UnityHelper.FindTheChildNode(transform, "Top/StarLavel/StarValue").GetComponent<Text>();
            Text attackedName = UnityHelper.FindTheChildNode(transform, "Top/AttackedName").GetComponent<Text>();

            // ERROR:一开始不知道谁是富豪
           // starValue.text = "" + CatchData.richPlayerInfo.StartCount;
           // attackedName.text = "" + CatchData.richPlayerInfo.NickName;
           // StartCoroutine(SystemTool.GetSpriteByURL(icon, CatchData.richPlayerInfo.Icon, null));
        }

        private void InstantiateModel(Transform root,PlayerInfo data)
        {
            CultivatePet curPet = data.petDictionary[data.CurrentCultivatePetId];
            MainSceneInit.instance.SceneInit(ref curPet);
            if (curPet.camera != null)
                curPet.camera.enabled = false;

            Vector3 randomPos = root.transform.position + new Vector3(UnityEngine.Random.Range(-4f, 4f), 0, UnityEngine.Random.Range(-5f, 5f));
            Quaternion randomRot = Quaternion.Euler(Vector3.up * UnityEngine.Random.Range(-180f, 180f));
            curPet.model.transform.position = randomPos;
            curPet.model.transform.rotation = randomRot;
            curPet.model.transform.SetParent(root);
            CatchPlayerController script = curPet.model.AddComponent<CatchPlayerController>();
            script.Init(data, cameraRoot);
            catchGoList.Add(curPet.model);
        }

        #region 网络事件

        private void GetRichPlayerListCallBack(string message)
        {
            Debug.Log(message);
            JsonData data = JsonMapper.ToObject(message);
            if (!data.IsArray)
            {

                #region 错误码解析
                int code = int.Parse(data["code"].ToJson().Replace("\"", ""));
                switch (code)
                {
                    case 90001:
                        NWarningManager.Instance.OpenDialogPanel(data["err_msg"].ToJson().Replace("\"", ""), () => { LoginManager.instance.LogOut(); });

                        break;
                    default:
                        NWarningManager.Instance.OpenErrorCode(data["err_msg"].ToJson().Replace("\"", ""), 2);

                        break;
                }
                #endregion
            }
            else
            {
                CatchData.CleanData();

                for (int i = 0; i < data.Count; i++)
                {
                    PlayerInfo info=new PlayerInfo();
                    CultivatePet cultivatePet = new CultivatePet();

                    info.NickName = data[i]["nick_name"].ToJson().Replace("\"", "");
                    info.Icon = data[i]["icon"].ToJson().Replace("\"", "");
                    info.CurrentCultivatePetId = data[i]["pet_id"].ToJson().Replace("\"", "");
                    info.userId = data[i]["user_id"].ToJson().Replace("\"", "");

                    cultivatePet.petId = info.CurrentCultivatePetId;
                    cultivatePet.petCode = int.Parse(data[i]["pet_code"].ToJson().Replace("\"", ""));
                    cultivatePet.petName = data[i]["name"].ToJson().Replace("\"", "");

                    for (int j = 1; j < 6; j++)
                    {
                        BodyPart bodyPart = new BodyPart(j, cultivatePet.userId, cultivatePet.petId);

                        cultivatePet.bodyPartDictionary.Add(j, bodyPart);
                    }

                    if (((IDictionary)data[i]).Contains("has_glass"))
                        cultivatePet.haeGlass = int.Parse(data[i]["has_glass"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[1].bodyPartLevel = int.Parse(data[i]["head_level"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[1].bodyPartStatus = int.Parse(data[i]["head_status"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[2].bodyPartLevel = int.Parse(data[i]["arm_level"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[2].bodyPartStatus = int.Parse(data[i]["arm_status"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[3].bodyPartLevel = int.Parse(data[i]["clothes_level"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[3].bodyPartStatus = int.Parse(data[i]["clothes_status"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[4].bodyPartLevel = int.Parse(data[i]["shoes_level"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[4].bodyPartStatus = int.Parse(data[i]["shoes_status"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[5].bodyPartLevel = int.Parse(data[i]["weapon_level"].ToJson().Replace("\"", ""));
                    cultivatePet.bodyPartDictionary[5].bodyPartStatus = int.Parse(data[i]["weapon_status"].ToJson().Replace("\"", ""));

                    cultivatePet.bodyPartDictionary[1].upgradeModel = UpgradeModel.COLOR;
                    cultivatePet.bodyPartDictionary[2].upgradeModel = UpgradeModel.MODEL;
                    cultivatePet.bodyPartDictionary[3].upgradeModel = UpgradeModel.COLOR;
                    cultivatePet.bodyPartDictionary[4].upgradeModel = UpgradeModel.COLOR;
                    cultivatePet.bodyPartDictionary[5].upgradeModel = UpgradeModel.COLOR;

                    if (!info.petDictionary.ContainsKey(cultivatePet.petId))
                    {
                        info.petDictionary.Add(cultivatePet.petId, cultivatePet);
                    }

                    CatchData.catchPlayerDictionary.Add(info.userId, info);
                }

                InitCatchScene();
            }
        }

        #endregion

    }
}
