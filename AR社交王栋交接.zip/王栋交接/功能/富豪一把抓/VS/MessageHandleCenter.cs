﻿/************************************************************************* 
文件：		MessageHandleCenter.cs
日期：		2017/12/24
时间：		14 : 15
版本：		v1.1
作者：		杨煌平
说明：      服务器回调类，及与服务器通信协议类
*************************************************************************/
using UnityEngine;
using System.Collections;


using LitJson;
using ND.ARGame.Define;
using ND.Game.BusinessFramework;

namespace ND.ARGame.Net
{
    public class MessageHandleCenter : TMonoSingleton<MessageHandleCenter>
    {
        void Awake() {
            this.gameObject.name = "NetManager";
            DontDestroyOnLoad(this);
        }

        public void Init() {
        }

        public void Release() {
        }

        #region 与服务器通信协议，服务器通过Android端回调

        #region 其他
        private void getCSSession(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_CS_SESSION, jsonMsg);
        }
        private void NETWORK(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.NETWORK, jsonMsg);
        }
       
        #endregion

        #region 角色
        private void login(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.LOGIN, jsonMsg);
        }
        private void modifyInfo(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.CREATE_ROLE, jsonMsg);
        }
        private void getFriendInfo(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_FRIEND_INFO, jsonMsg);
        }
        private void kickOff(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.KICK_OFF, jsonMsg);
        }
        private void getUserCoin(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_USER_COIN, jsonMsg);
        }
        private void getEnergy(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_ENERGY, jsonMsg);
        } 
        #endregion

        #region 宠物
        private void matchPet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.MATCHP_PET, jsonMsg);
        }
        private void capturePet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.CAPTURE_PET, jsonMsg);
        }
        private void getPetList(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_PET_LIST, jsonMsg);
        }
        private void getMatchCount(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_MATCH_COUNT, jsonMsg);
        }
        private void getPetInfo(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_PET_INFO, jsonMsg);
        }
        private void sellPet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.SELL_PET, jsonMsg);
        }
        private void getDefPetTeam(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_DEF_PET_TEAM, jsonMsg);
        }
        private void setDefPetTeam(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.SET_DEF_PET_TEAM, jsonMsg);
        }
        #endregion

        #region 战斗
        private void getRoomList(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_ROOM_LIST, jsonMsg);
        }
        private void joinRoom(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.JOIN_ROOM, jsonMsg);
        }
        private void leaveRoom(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.LEAVE_ROOM, jsonMsg);
        }
        private void quickJoin(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.QUICK_JOIN, jsonMsg);
        }
        private void getRoomInfo(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_ROOM_INFO, jsonMsg);
        }
        private void readyBattle(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.READY_BATTLE, jsonMsg);
        }
        private void cancelReady(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.CANCEL_READY, jsonMsg);
        }
        private void startBattle(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.START_BATTLE, jsonMsg);
        }
        private void notifyPlayer(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.NOTIFY_PLAYER, jsonMsg);
        }
        #endregion

        #region 主题乐园
        private void getThemePark(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_THEME_PARK, jsonMsg);
        }
        private void upgradeBuilding(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.UPGRADE_BUILDING, jsonMsg);
        }
        private void equipPet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.EQUIP_PET, jsonMsg);
        }
        private void teardownPet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.TEAR_DOWN_PET, jsonMsg);
        }
        private void setFollowPet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.SET_FOLLOW_PET, jsonMsg);
        }
        private void drawLottery(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.DRAW_LOTTERY, jsonMsg);
        }
        #endregion

        #region 攻击
        private void setCultivatePet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.SET_CULTIVATE_PET, jsonMsg);
        }
        private void upgradePetPart(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.UPGRADE_PET_PART, jsonMsg);
        }
        private void attackPet(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.ATTACK_PET, jsonMsg);

        }
        private void notifyAttack(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.NOTIFY_ATTACK, jsonMsg);

        }
        private void getRandFriendInfo(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_RAND_FRIEND_INFO, jsonMsg);
        }
        private void repairPetPart(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.REPAIR_PET_PART, jsonMsg);
        }
        private void getRichPlayerList(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_RICH_PLAYER_LIST, jsonMsg);
        }
        private void catchPlayerList(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.CATCH_PLAYER_LIST, jsonMsg);
        }
        #endregion

        #region 好友
        private void addFriend(string jsonMsg)
        {
            Debug.LogError("添加好友请求回掉");
            EventCenter.Brocast<string>(MsgEventType.ADD_FRIEND, jsonMsg);
        }

        private void getFriendList(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_FRIEND_LIST,jsonMsg);
        }

        private void getEnemyList(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_ENEMY_LIST, jsonMsg);
        }

        private void dealAddFriend(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.DEAL_ADD_FRIEND, jsonMsg);
        }

        private void getUnReadMsg(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.GET_UN_READ_MSG, jsonMsg);
        }
        private void notifyAddFriend(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.NOTIFY_ADD_FRIEND, jsonMsg);
        }

        private void notifyDealAddFriend(string jsonMsg)
        {
            EventCenter.Brocast<string>(MsgEventType.NOTIFY_DEAL_ADD_FRIEND, jsonMsg);
        }
        #endregion
        #endregion
    } 
}
