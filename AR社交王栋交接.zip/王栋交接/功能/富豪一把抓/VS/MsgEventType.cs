﻿using UnityEngine;
using System.Collections;

namespace ND.ARGame.Define
{
    public class MsgEventType
    {
        #region 服务器端通信协议

        #region 其他
        public static readonly string GET_CS_SESSION = "getCSSession";
        public static readonly string NETWORK = "NETWORK";
        public static readonly string On_CREATE = "OnCreate";
        public static readonly string ON_NEW_INTENT = "onNewIntent";
        public static readonly string ND_LOGIN_INIT = "ndLoginInit";
        public static readonly string ND_LOGIN_SUCCESS = "ndLoginSuccess";
        public static readonly string ND_LOGIN_FAIL = "ndLoginFail";
        public static readonly string UC_LOGIN_FAIL = "ucLoginFail";
        #endregion

        #region 角色
        public static readonly string LOGIN = "login";
        public static readonly string CREATE_ROLE = "modifyInfo";
        public static readonly string GET_FRIEND_INFO = "getFriendInfo";
        public static readonly string KICK_OFF = "kickOff";
        public static readonly string GET_USER_COIN = "getUserCoin";
        public static readonly string GET_ENERGY = "getEnergy";
        #endregion

        #region 宠物
        public static readonly string MATCHP_PET = "matchPet";
        public static readonly string CAPTURE_PET = "capturePet";
        public static readonly string GET_PET_LIST = "getPetList";
        public static readonly string GET_MATCH_COUNT = "getMatchCount";
        public static readonly string GET_PET_INFO = "getPetInfo";
        public static readonly string SELL_PET = "sellPet";
        public static readonly string GET_DEF_PET_TEAM = "getDefPetTeam";
        public static readonly string SET_DEF_PET_TEAM = "setDefPetTeam";
        #endregion

        #region 战斗
        public static readonly string GET_ROOM_LIST = "getRoomList";
        public static readonly string JOIN_ROOM = "joinRoom";
        public static readonly string LEAVE_ROOM = "leaveRoom";
        public static readonly string QUICK_JOIN = "quickJoin";
        public static readonly string GET_ROOM_INFO = "getRoomInfo";
        public static readonly string READY_BATTLE = "readyBattle";
        public static readonly string CANCEL_READY = "cancelReady";
        public static readonly string START_BATTLE = "startBattle";
        public static readonly string NOTIFY_PLAYER = "notifyPlayer";
        #endregion

        #region 主题乐园
        public static readonly string GET_THEME_PARK = "getThemePark";
        public static readonly string UPGRADE_BUILDING = "upgradeBuilding";
        public static readonly string EQUIP_PET = "equipPet";
        public static readonly string TEAR_DOWN_PET = "teardownPet";
        public static readonly string SET_FOLLOW_PET = "setFollowPet";
        public static readonly string DRAW_LOTTERY = "drawLottery";
        #endregion

        #region 攻击
        public static readonly string SET_CULTIVATE_PET = "setCultivatePet";
        public static readonly string UPGRADE_PET_PART = "upgradePetPart";
        public static readonly string ATTACK_PET = "attackPet";
        public static readonly string NOTIFY_ATTACK = "notifyAttack";
        public static readonly string GET_RAND_FRIEND_INFO = "getRandFriendInfo";
        public static readonly string REPAIR_PET_PART = "repairPetPart";
        public static readonly string GET_RICH_PLAYER_LIST = "getRichPlayerList";
        public static readonly string CATCH_PLAYER_LIST = "catchPlayerList";
        #endregion

        #region 好友
        public static readonly string ADD_FRIEND = "addFriend";
        public static readonly string GET_FRIEND_LIST = "getFriendList";
        public static readonly string GET_ENEMY_LIST = "getEnemyList";
        public static readonly string DEAL_ADD_FRIEND = "dealAddFriend";
        public static readonly string GET_UN_READ_MSG = "getUnReadMsg";
        public static readonly string NOTIFY_ADD_FRIEND = "notifyAddFriend";
        public static readonly string NOTIFY_DEAL_ADD_FRIEND = "notifyDealAddFriend";
        #endregion
       
        #endregion

        #region Android端通信协议
        // 协议需与Android端协商进行重构
        public static readonly string SCAN_TYPE = "0"; // 识别场景
        public static readonly string PET_LIST = "1"; // 宠物列表
        public static readonly string COMBAT = "2"; // 宠物列表
        public static readonly string PACKAGE_DETAIL = "3"; // 背包详情
        public static readonly string START_CREATE_ROLE = "4"; // 创建角色场景
        public static readonly string SHOW_ROLE = "5"; // 查看角色场景
        public static readonly string GOD_RESIDENCE = "6"; // 神仙居
        public static readonly string APARTMENT = "7"; // 公寓
        public static readonly string PAT_MAP = "8"; // 宠物图鉴

        #endregion
    } 
}
