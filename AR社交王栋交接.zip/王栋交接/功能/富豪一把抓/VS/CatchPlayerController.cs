﻿using System;
using UnityEngine;
using UnityEngine.UI;
using ND.ARGame.Data;
using ND.Game.BusinessFramework;

namespace ND.Game.UILogic
{

    public class CatchPlayerController : MonoBehaviour
    {
        private const string ModelPath = "UI/Prefabs/Catch/";
        private CharacterController controller;
        private float speed = 2f;
        private int state = 0;  // 0移动 1转向
        private Vector3 targetDirection;
        private Transform canvasTran;
        private Transform cameraTran;

        public Text moneyText;
        public GameObject catchDialog;
        public GameObject unCatchDialog;

        public PlayerInfo playerInfo;


        public void Init(PlayerInfo info,Transform camTran)
        {
            controller = gameObject.AddComponent<CharacterController>();
            controller.stepOffset = 0.03f;
            controller.center = Vector3.up * 0.97f;

            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.MODEL, ModelPath + "CatchModelCanvas", go =>
            {
                canvasTran = Instantiate(go).transform;
                canvasTran.SetParent(transform);
                canvasTran.GetComponent<RectTransform>().localPosition = Vector3.up * 0.6f;
            });

            cameraTran = camTran;
            moneyText = canvasTran.FindChild("Money").GetComponent<Text>();
            catchDialog = canvasTran.FindChild("CatchDialog").gameObject;
            unCatchDialog = canvasTran.FindChild("UnCatchDialog").gameObject;
            playerInfo = info;
        }

        private void Update()
        {
            if(CatchData.isCompleteCatch)
            {
                return;
            }

            Debug.DrawRay(transform.position, targetDirection, Color.red);
            Debug.DrawRay(transform.position, transform.forward, Color.green);

            if(state==0)
            {
               controller.SimpleMove(speed * transform.forward);
            }
            else if(state==1)
            {
                transform.forward = Vector3.RotateTowards(transform.forward, targetDirection, 0.1f, 0.1f);

                if (Vector3.Angle(transform.forward, targetDirection)<1f)
                {
                    state = 0;
                }
            }
            canvasTran.forward = -cameraTran.forward;
        }

        private void OnControllerColliderHit(ControllerColliderHit hit)
        {
            if(hit.normal!=Vector3.up&&state==0)
            {
                state = 1;
                if(hit.transform.parent.name.Equals("Wall"))
                {
                    targetDirection = Vector3.Reflect(transform.forward, hit.normal);
                }
                else
                {
                    targetDirection = -transform.forward;
                }
                targetDirection.y = 0;
            }
        }
    }
}
