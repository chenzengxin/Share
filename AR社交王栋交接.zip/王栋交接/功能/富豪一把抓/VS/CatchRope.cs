﻿using System;
using System.Collections;
using System.Collections.Generic;
using ND.ARGame.Data;
using ND.Game.BusinessFramework;
using UnityEngine;
using LitJson;
using ND.ARGame.Define;
using ND.ARGame.Login;
using ND.ARGame.Net;
using ND.Events;

namespace ND.Game.UILogic
{

    public class CatchRope : MonoBehaviour
    {

        public Transform target;
        private float moveSpeed=0.5f;
        private float catchRadius = 1.8f;

        private List<GameObject> catchedGoList = new List<GameObject>();

        private void Start()
        {
            EventCenter.AddListener<string>(MsgEventType.CATCH_PLAYER_LIST, CatchPlayerListCallBack);
        }

        private void OnDestroy()
        {
            EventCenter.RemoveListener<string>(MsgEventType.CATCH_PLAYER_LIST, CatchPlayerListCallBack);
        }

        private void Update()
        {
            Debug.DrawLine(target.position, target.position + new Vector3(catchRadius, 0, catchRadius));
            if(CatchData.isCompleteCatch)
            {
                return;
            }

            if(Vector3.Distance(transform.position,target.position)>1f)
            {
                transform.Translate((target.position - transform.position).normalized * moveSpeed);
            }
            else
            {
                CatchData.isCompleteCatch = true;
                RequestCatchPlayerList();

                //UnityEngine.TextAsset s = Resources.Load("myjson1") as TextAsset;
               // CatchPlayerListCallBack(s.text);
            }
        }

        private void RequestCatchPlayerList()
        {
            JsonData data = new JsonData();

            JsonData arrayData = new JsonData();
            arrayData.SetJsonType(JsonType.Array);

            data["user_ids"] = arrayData;

            foreach (var go in CatchUI.Instance.catchGoList)
            {
                PlayerInfo info = go.GetComponent<CatchPlayerController>().playerInfo;
                if (Vector3.Distance(go.transform.position, target.position) < catchRadius)
                {
                    data["user_ids"].Add(info.userId);
                }
            }

            NetManager.instance.Request(MsgEventType.CATCH_PLAYER_LIST, data.ToJson());
        }

        private void CatchPlayerListCallBack(string message)
        {
            Debug.Log(message);
            JsonData data = JsonMapper.ToObject(message);
            if (!data.IsArray)
            {

                #region 错误码解析
                int code = int.Parse(data["code"].ToJson().Replace("\"", ""));
                switch (code)
                {
                    case 90001:
                        NWarningManager.Instance.OpenDialogPanel(data["err_msg"].ToJson().Replace("\"", ""), () => { LoginManager.instance.LogOut(); });

                        break;
                    default:
                        NWarningManager.Instance.OpenErrorCode(data["err_msg"].ToJson().Replace("\"", ""), 2);

                        break;
                }
                #endregion
            }
            else
            {

                for (int i = 0; i < data.Count; i++)
                {
                    string user_id=data[i]["user_id"].ToJson().Replace("\"", "");
                    PlayerInfo info = CatchData.catchPlayerDictionary[user_id];
                    info.CoinCount = long.Parse(data[i]["coin"].ToJson().Replace("\"", ""));
                    info.StealCoin = long.Parse(data[i]["steal_coin"].ToJson().Replace("\"", ""));

                    if(info.CoinCount>=100000&&info.StealCoin!=-1)
                    {
                        CatchData.richerUserId = info.userId;
                    }
                }
                StartCoroutine(ShowMoney());
            }
        }

        private IEnumerator ShowMoney()
        {

            LineRenderer lineRenderer = GetComponent<LineRenderer>();
            int section = 100;
            Vector3[] position = new Vector3[section];

            for (int i = 0; i < section; i++)
            {
                float angle = 360f / section * i;
                Vector3 dir = Quaternion.Euler(Vector3.up * angle) * target.forward * catchRadius;
                position[i] = target.position + dir;
            }
            lineRenderer.SetPositions(position);


            CatchPlayerController richerPlayer = null;
            
            foreach (var go in CatchUI.Instance.catchGoList)
            {
                CatchPlayerController script = go.GetComponent<CatchPlayerController>();
                PlayerInfo info = script.playerInfo;
                script.moneyText.text = info.CoinCount.ToString();

                if (info.userId == CatchData.richerUserId)
                {
                    richerPlayer = script;
                }
                else if (info.StealCoin != -1)
                {
                    yield return new WaitForSeconds(1);
                    script.moneyText.gameObject.SetActive(true);
                }
            }

           if(richerPlayer!=null)
           {
               yield return new WaitForSeconds(1);

               if (CatchData.richerUserId != null)
               {
                   richerPlayer.moneyText.gameObject.SetActive(true);
                   richerPlayer.catchDialog.SetActive(true);
               }
               else
               {
                   richerPlayer.unCatchDialog.SetActive(true);
               }
           }

           yield return new WaitForSeconds(1);
           CatchUI.Instance.SwitchToResultPannel();
        }


    }
}