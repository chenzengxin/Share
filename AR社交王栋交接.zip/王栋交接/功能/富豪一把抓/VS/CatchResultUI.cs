﻿using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using ND.ARGame.Data;
using ND.Events;
using ND.Game.BusinessFramework;
using ND.Game.GameLogic;
using ND.Utils;
using LitJson;
using System.Collections;
using ND.ARGame.Net;
using ND.ARGame.Define;
using ND.ARGame.Login;
using ND.ARGame.Manager;
using DG.Tweening;

namespace ND.Game.UILogic
{
    public class NativeShare
    {

        public void Share(string imagePath)
        {
            CoroutineHelper.DoStartCoroutine(CaptureAndSave(new UnityEngine.Rect(0, 0, Screen.width, Screen.height), imagePath, delegate
            {
#if UNITY_ANDROID
                using (AndroidJavaClass jc = new AndroidJavaClass("com.nd.arplay.unitylbs.presenter.UnityBridge"))
                {
                    using (AndroidJavaObject jo = jc.CallStatic<AndroidJavaObject>("getInstance"))
                    {
                        using (AndroidJavaClass jcCurrent = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                        {
                            using (AndroidJavaObject joCurrent = jcCurrent.GetStatic<AndroidJavaObject>("currentActivity"))
                            {
                                jo.Call("goShare", imagePath, joCurrent);
                            }
                        }
                    }
                }
#endif
               
            }));
        }

        private IEnumerator CaptureAndSave(UnityEngine.Rect mRect, string mFileName, Action callback)
        {
            yield return new WaitForEndOfFrame();
            Texture2D mTexture = new Texture2D((int)mRect.width, (int)mRect.height, TextureFormat.RGB24, true);
            mTexture.ReadPixels(mRect, 0, 0, true);
            mTexture.Apply();

            TextureUtility.ScalePoint(mTexture, mTexture.width / 2, mTexture.height / 2);
            byte[] bytes = mTexture.EncodeToJPG();
            File.WriteAllBytes(mFileName, bytes);
            if (callback != null)
                callback();
        }
    }

    public class CatchResultUI : UIMonoSingleton<CatchResultUI>
    {

        private const string ModelPath = "UI/Prefabs/Catch/";

        private GameObject catchResultModel;
        private long resultCoin;
        private bool isNeedShare = false;
        private string shareImagePath;

        public override void OnInit()
        {
            RigisterButtonObjectEvent("Bottom/SureBtn", OnSureButtonClick);
            UnityHelper.FindTheChildNode(transform, "Bottom/ShareToggle").GetComponent<Toggle>().onValueChanged.AddListener((bool arg) => { isNeedShare = arg; });
            shareImagePath = Application.persistentDataPath + "/share.png";
        }

        public override void RedisplayInit()
        {
            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.MODEL, ModelPath + "CatchResultModel", go =>
            {
                List<PlayerInfo> catchedPlayerList = new List<PlayerInfo>();

                foreach(var info in CatchData.catchPlayerDictionary)
                {
                    if(info.Value.StealCoin!=-1)
                    {
                        if(CatchData.richerUserId!=null&&info.Value.userId==CatchData.richerUserId)
                        {
                            continue;
                        }
                        catchedPlayerList.Add(info.Value);
                    }
                }

                catchResultModel = GameObject.Instantiate(go);
                Transform modelRoot = UnityHelper.FindTheChildNode(catchResultModel.transform, "ModelRoot");
                Transform modelParent;
                int index = CatchData.richerUserId != null ? catchedPlayerList.Count : catchedPlayerList.Count - 1;

                int startIndex = 0;
                if (CatchData.richerUserId != null)
                {
                    modelParent = modelRoot.GetChild(index).GetChild(0);
                    InstantiateModel(modelParent, CatchData.catchPlayerDictionary[CatchData.richerUserId]);
                    UnityHelper.FindTheChildNode(transform, "Bottom/ResultText").GetComponent<Text>().text = "抓住了富豪，成功获得";
                    startIndex = 1;
                }

                for (int i = 0; i < catchedPlayerList.Count;i++ )
                {
                    modelParent = modelRoot.GetChild(index).GetChild(startIndex+i);
                    InstantiateModel(modelParent, catchedPlayerList[i]);
                }
            });

            UnityHelper.FindTheChildNode(transform, "ResultMoney").GetComponent<Text>().text=resultCoin.ToString();
            UnityHelper.FindTheChildNode(transform, "Bottom/CoinValue").GetComponent<Text>().text = resultCoin.ToString();

            if (File.Exists(shareImagePath))
            {
                File.Delete(shareImagePath);
            }
        }

        public override void OnAfterHide()
        {
            GameObject.Destroy(catchResultModel);
        }

        private void OnSureButtonClick(GameObject go)
        {
            if(isNeedShare)
            {
                NativeShare share = new NativeShare();
                share.Share(shareImagePath);
            }
            StartCoroutine(MyCloseUIForm());
        }

        private IEnumerator MyCloseUIForm()
        {
            yield return new WaitForEndOfFrame();   

            Player.instance.GetPlayerInfo().CoinCount += resultCoin;
            CloseUIForm();
        }

        private void InstantiateModel(Transform root,PlayerInfo data)
        {
            resultCoin += data.StealCoin;
            CultivatePet curPet = data.petDictionary[data.CurrentCultivatePetId];
            MainSceneInit.instance.SceneInit(ref curPet);
            if (curPet.camera != null)
                curPet.camera.enabled = false;

            curPet.model.transform.position = root.position;
            curPet.model.transform.SetParent(root);
            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.MODEL, ModelPath + "CatchModelCanvas", go =>
            {
                Transform canvasTran = Instantiate(go).transform;
                canvasTran.SetParent(curPet.model.transform);
                canvasTran.GetComponent<RectTransform>().localPosition = Vector3.up*0.6f;
                Transform resultUI = canvasTran.FindChild("ResultUI");
                resultUI.gameObject.SetActive(true);
                UnityHelper.FindTheChildNode(resultUI, "ResultMoney").GetComponent<Text>().text = data.StealCoin.ToString();
                Image icon = UnityHelper.FindTheChildNode(resultUI, "IconMask/Icon").GetComponent<Image>();
                //StartCoroutine(SystemTool.GetSpriteByURL(icon, CatchData.richPlayerInfo.Icon, null));

                if (data.userId == CatchData.richerUserId)
                {
                    UnityHelper.FindTheChildNode(resultUI, "IsRicher").gameObject.SetActive(true);
                }
            });
        }
    }
}
