﻿using ND.Game.BusinessFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine.UI;
using UnityEngine;
using ND.ARGame.Login;
using System.Collections;
using ND.ARGame.Define;
using LitJson;
using ND.ARGame.Data;
using ND.ARGame.Net;
using ND.Utils;
using ND.Events;
using DG.Tweening;

namespace ND.Game.UILogic
{
    public class LotteryUI : UIMonoSingleton<LotteryUI>
    { 
        #region 对象
        private Button btn_StartLottery;
        private Button btn_OpenPetUI;
        private Transform Pnl_PPInfo;
        private Text txt_Timer;
        private Text txt_AddPP;
        private Text txt_PP;
        //private Image img_LotteryBg;
        private Transform Pnl_Reward;
        private Image img_Reward;
        private Text txt_RewardCount;
        private Button btn_OpenPetList;
        private Transform Pnl_Lottery;
        private Transform Pnl_Bottom;
        private Transform btn_Role;
        private Transform img_LotteryBg;

        //private ParticleSystem getGold;
        //private ParticleSystem getPower;
        //private ParticleSystem getShield;

        private Transform uiCanvas;
        private GameObject transitionsCloud;

        #endregion

        #region 变量
        private Vector3 PetCameraPos;  //3D摄像机位置
        private CultivatePet curPet;  //宠物
        //private Tick tick;
        private Timer time;
        /// <summary>
        /// 转盘速度
        /// </summary>
        private float lotterySpeed = 3f;  //1秒转几圈 1圈360
        private float lotteryUptime = 1.0f;  //客户端加速时间
        private float lotteryTimer = 1.0f;   //客户端匀速表现时间
        private float lottertCircle = 1.0f;   //收到服务端消息后定位之前多跑的圈数 
        /// <summary>
        /// 转换成时间格式的时、分、秒
        /// </summary>
        private long h, m, s;
        /// <summary>
        /// 剩余体力恢复时间
        /// </summary>
        private long needTime;
        private Coroutine recoverTimeCoroutine = null;
        public LotteryInfo lotteryInfo = null;
        /// <summary>
        /// 是否收到服务端消息
        /// </summary>
        private bool isReturn;
        private bool isARBtnUp;
        /// <summary>
        /// 转盘是否要停止转
        /// </summary>
        private bool isNeedStop;
        #endregion

        #region 属性
        //private bool isLotterying;
        ///// <summary>
        ///// 是否在抽奖
        ///// </summary>
        //public bool IsLotterying
        //{
        //    get { return isLotterying; }
        //    set { isLotterying = value; }
        //}
        #endregion

        void FixedUpdate()
        {
            if (!isNeedStop && ARGameState.Instance.isLotterying)
            {
                img_LotteryBg.transform.Rotate(new Vector3(0, 0, -1) * (lotterySpeed * Time.fixedDeltaTime * 360)); 
            }
                               
        }

        public override void OnInit()
        {
            btn_StartLottery = UnityHelper.FindTheChildNode(transform, "Pnl_Bottom/btn_StartLottery").GetComponent<Button>();
            btn_OpenPetUI = UnityHelper.FindTheChildNode(transform, "Pnl_Bottom/btn_OpenPetUI").GetComponent<Button>();
            btn_OpenPetList = UnityHelper.FindTheChildNode(transform, "Pnl_Bottom/btn_OpenPetList").GetComponent<Button>();
            Pnl_PPInfo = UnityHelper.FindTheChildNode(transform, "Pnl_PPInfo");
            txt_Timer = UnityHelper.FindTheChildNode(transform, "Pnl_Bottom/Pnl_PPInfo/txt_Timer").GetComponent<Text>();
            txt_AddPP = UnityHelper.FindTheChildNode(transform, "Pnl_Bottom/Pnl_PPInfo/txt_AddPP").GetComponent<Text>();
            txt_PP = UnityHelper.FindTheChildNode(transform, "Pnl_Bottom/txt_PP").GetComponent<Text>();
            //img_LotteryBg = UnityHelper.FindTheChildNode(transform, "Pnl_Lottery/img_LotteryBg").GetComponent<Image>();
            Pnl_Reward = UnityHelper.FindTheChildNode(transform, "Pnl_Reward");
            img_Reward = UnityHelper.FindTheChildNode(transform, "Pnl_Reward/img_Reward").GetComponent<Image>();
            txt_RewardCount = UnityHelper.FindTheChildNode(transform, "Pnl_Reward/txt_RewardCount").GetComponent<Text>();
            Pnl_Lottery = UnityHelper.FindTheChildNode(transform, "Pnl_Lottery");
            Pnl_Bottom = UnityHelper.FindTheChildNode(transform, "Pnl_Bottom");
            btn_Role = UnityHelper.FindTheChildNode(transform, "img_Role/btn_Role");

            uiCanvas = this.transform.parent;
            //curPet = Player.instance.GetPlayerInfo().petDictionary[Player.instance.GetPlayerInfo().CurrentCultivatePetId];
            transitionsCloud = Resources.Load<GameObject>("Prefabs/Effect_Prefab/eff_TransitionsCloud");


            //RigisterButtonObjectEvent(btn_Role.transform, OpenPetUIBtnCallback);
            RigisterButtonObjectEvent(btn_OpenPetUI.transform, OpenPetUIBtnCallback);
   
            
        }

        public override void RedisplayInit()
        {
            StartCoroutine(Wait());
            //-1.01  0.73  7.27        
            curPet = Player.instance.GetPlayerInfo().
                                        petDictionary[Player.instance.GetPlayerInfo().CurrentCultivatePetId];
            MainSceneInit.instance.SceneInit(ref curPet);
            img_LotteryBg = UnityHelper.FindTheChildNode(curPet.lotteryObject.transform, "LotteryBg/img_LotteryBg");
            //PetCameraPos = curPet.bodyPartDictionary[1].camera.transform.localPosition;
            curPet.bodyPartDictionary[1].camera.transform.localPosition = new Vector3(-1.01f, 0.73f, 7.27f);
            curPet.animator.SetBool("IsLottery", true);
            //curPet.model.transform.FindChild("Model").localEulerAngles = new Vector3(0, -10, 0);
            curPet.lotteryObject.SetActive(true);
            curPet.model.SetActive(true);
           

            ARGameMainUI.Instance.SetDrawLotteryBtn(false);
            ARGameMainUI.Instance.SetAddPetBtn(false);
            btn_OpenPetList.gameObject.SetActive(false);
            Pnl_Lottery.gameObject.SetActive(false);
            //btn_OpenPetUI.gameObject.SetActive(false);

            img_LotteryBg.transform.localRotation = Quaternion.identity;  //恢复转盘位置

            //isReturn = false;
            //isNeedStop = true;
            ResetLotteryParam();

            Pnl_Reward.gameObject.SetActive(false);
            OnSetCurPP();
            
            txt_AddPP.text = "+" + ConstantDefine.RegainPPCount;
            txt_Timer.text = string.Empty;

            Pnl_PPInfo.gameObject.SetActive(false);

            Pnl_Reward.gameObject.AddComponent<ARCode.Script.Framework.Game.GameMain.UI.ClickClose>();
            Player.instance.GetPlayerInfo().AddLisiten(ND.ARGame.Data.EventType.setRecoverTimeEvent, OnSetRecoverTime);
            Player.instance.GetPlayerInfo().AddLisiten(ND.ARGame.Data.EventType.setCurPPEvent, OnSetCurPP);
            EventCenter.AddListener<string>(MsgEventType.DRAW_LOTTERY, DrawLotteryCallBack);
            EventCenter.AddListener<string>(MsgEventType.GET_ENERGY, GetEnergyRequestCallBack);
          
            EventTriggerListener.GetListener(btn_StartLottery.gameObject).onPointerDown += OnARBtnDown;
            EventTriggerListener.GetListener(btn_StartLottery.gameObject).onPointerUp += OnARBtnUp;

            GetEnergyRequest();
            OpenUIAction();
        }

        IEnumerator Wait()
        {
            yield return new WaitForSeconds(2);
            print(1222222);
            UIManageMessageHandle.Instance.CloseMessagePanel();
        }


        public override void OnAfterHide()
        {
            EventCenter.RemoveListener<string>(MsgEventType.DRAW_LOTTERY, DrawLotteryCallBack);
            EventCenter.RemoveListener<string>(MsgEventType.GET_ENERGY, GetEnergyRequestCallBack);
            
            Player.instance.GetPlayerInfo().RemoveLisiten(ND.ARGame.Data.EventType.setRecoverTimeEvent, OnSetRecoverTime);
            Player.instance.GetPlayerInfo().RemoveLisiten(ND.ARGame.Data.EventType.setCurPPEvent, OnSetCurPP);          

            EventTriggerListener.GetListener(btn_StartLottery.gameObject).onPointerDown -= OnARBtnDown;
            EventTriggerListener.GetListener(btn_StartLottery.gameObject).onPointerUp -= OnARBtnUp;

            if (recoverTimeCoroutine != null)
            {
                StopCoroutine(recoverTimeCoroutine);
                recoverTimeCoroutine = null;
            }

            if (curPet != null && curPet.model != null)
                Destroy(curPet.model);
            curPet = null;

        }
        /// <summary>
        /// 开启界面表现
        /// </summary> 
        void OpenUIAction()
        {
            //OnBeginAnimation();
            //表现
            //Pnl_Lottery.localScale = Vector3.zero;
            //Pnl_Lottery.DOScale(new Vector3(1f, 1f, 1f), 0.5f).SetEase(Ease.InCubic);


            //Pnl_Bottom.localPosition = new Vector3(0f, -740f, 0f);
            //Pnl_Bottom.DOLocalMoveY(-541.5f, 0.5f).SetEase(Ease.InCubic).OnComplete(() => { OnEndAnimation(); });
        }
        /// <summary>
        /// 关闭界面表现
        /// </summary> 
        private IEnumerator CloseUIAction(string uiFormName)
        {
            Debug.Log("sss");

            //OnBeginAnimation();     
            //表现
            //Pnl_Lottery.localScale = new Vector3(1f, 1f, 1f);
            //Pnl_Lottery.DOScale(Vector3.zero, 0.5f).SetEase(Ease.OutCubic);

            //curPet.animator.SetBool("IsLottery", false);
            //curPet.lotteryObject.SetActive(false);

            //curPet.bodyPartDictionary[1].camera.transform.localPosition = PetCameraPos;

            UIManageMessageHandle.Instance.LoadMessagePanel();
            GameObject go = GameObject.Instantiate(transitionsCloud);
            go.transform.SetParent(ND.Game.BusinessFramework.UIManager.Instance.switchCanvas);
            go.transform.localPosition = Vector3.zero;
            go.transform.localScale = Vector3.one;

            yield return new WaitForSeconds(1);

            Destroy(go, 2.0f);



            //Pnl_Bottom.localPosition = new Vector3(0f, -541.5f, 0f);
            //Pnl_Bottom.DOLocalMoveY(-740f, 0.5f).SetDelay(2.5f).SetEase(Ease.OutCubic).OnComplete(
            //    () => {
                    //OnEndAnimation();
                    
                    switch (uiFormName)
                    {
                        case "PetCultivateUI":
                            ARGameMainUI.Instance.SetDrawLotteryBtn(true);
                            CloseUIForm();
                            OpenUIForm("PetCultivateUI", UIFormType.Switch, UIFormShowMode.Overlay, 0);
                            
                            break;
                        case "Pet/PetListUI":
                            OpenUIForm("Pet/PetListUI", UIFormType.Switch, UIFormShowMode.Overlay);
                            break;

                        case "AddBtn":
                            CloseUIForm();
                            ARGameMainUI.Instance.SetAddPetBtn(true);
                            ARGameMainUI.Instance.SetDrawLotteryBtn(true);
                            break;

                        case "AttackUI":
                            OpenUIForm("AttackUI", UIFormType.Switch, UIFormShowMode.HideOther);
                            break;

                        case "Catch/CatchUI":
                            OpenUIForm("Catch/CatchUI", UIFormType.Switch, UIFormShowMode.HideOther);
                            break;

                        default:
                            CloseUIForm();
                            break;
                    }
                //});  
                    //ND.Game.BusinessFramework.UIManager.Instance.CloseLoadMessagePanel();
        }


        void OnARBtnDown(GameObject go)
        {
            isARBtnUp = false;
            StartLotteryBtnCallback();
        }

        void OnARBtnUp(GameObject go)
        {
            isARBtnUp = true;
        }


        /// <summary>
        /// 开启按钮
        /// </summary> 
        //void StartLotteryBtnCallback(GameObject obj)
        void StartLotteryBtnCallback()
        {
            if (ARGameState.Instance.isLotterying)
                return;
            
            if (Player.instance.GetPlayerInfo().CurPP <= 0)
            {
                NWarningManager.Instance.OpenDialogPanel("当前体力值不足", null);
                return;
            }
            SoundManager.Instance.PlaySound(SoundType.UISound, SoundPlayType.Only, "UI_Audio/ZhuanPanDong");
            ARGameState.Instance.isLotterying = true;
            isNeedStop = false;
            DrawLotteryRequest();  
            //客户端先转
            img_LotteryBg.transform.DOLocalRotate(new Vector3(0f, 0f, -(lotterySpeed * lotteryTimer * 360f)), lotteryUptime, RotateMode.LocalAxisAdd).SetEase(Ease.InQuad).OnComplete(() =>
                {
                    time = new Timer(lotteryTimer, int.MaxValue);
                    time.AddEventListener(TimerEvent.TIMER, OnDrawLotteryStart);
                    time.Start();       
                }
            );
        } 

        /// <summary>
        /// 打开宠物模型界面
        /// </summary> 
        void OpenPetUIBtnCallback(GameObject obj)
        {
            if (ARGameState.Instance.isLotterying)
                return;
            //CloseUIForm();
            //OpenUIForm("PetCultivateUI", UIFormType.Switch, UIFormShowMode.Overlay,0);
            if (Player.instance.GetPlayerInfo().CurrentCultivatePetId == "0")
            {
                //NWarningManager.Instance.OpenPromptPanel("请先到宠物列表选择一只宠物！", 2);
                //return;
                StartCoroutine(CloseUIAction("AddBtn"));
                return;
            }
            StartCoroutine(CloseUIAction("PetCultivateUI"));
        }
        /// <summary>
        /// 打开宠物列表界面
        /// </summary> 
        void OpenPetListBtnCallback(GameObject obj)
        {
            if (ARGameState.Instance.isLotterying)
                return;
            //CloseUIForm();
            //OpenUIForm("Pet/PetListUI", UIFormType.Switch, UIFormShowMode.Overlay);
            StartCoroutine(CloseUIAction("Pet/PetListUI"));
        }
        /// <summary>
        /// 界面剩余时间显示设置
        /// </summary> 
        void OnSetRecoverTime()
        {
            //Debug.Log("OnSetRecoverTime12345");
            needTime = Player.instance.GetPlayerInfo().RecoverTime;
            if (needTime >= 0 && Player.instance.GetPlayerInfo().CurPP < ConstantDefine.MAXPP)
            {
                if (needTime == 0)
                {
                    needTime = 3600;
                }
                Pnl_PPInfo.gameObject.SetActive(true);                
                h = SystemTools.TimeFormatReturnHour(needTime);
                m = SystemTools.TimeFormatReturnMin(needTime);
                s = SystemTools.TimeFormatReturnSec(needTime);
                if (recoverTimeCoroutine == null)
                    recoverTimeCoroutine = StartCoroutine(RecoverTimeCountDown());
            }
            else
            {
                txt_Timer.text = string.Empty;
                Pnl_PPInfo.gameObject.SetActive(false);
            }

        }
        /// <summary>
        /// 界面体力设置
        /// </summary> 
        void OnSetCurPP()
        {
            if (Player.instance.GetPlayerInfo().CurPP > 0 )
                txt_PP.text = "<color=#323232FF>" + Player.instance.GetPlayerInfo().CurPP + "</color>/" + ConstantDefine.MAXPP;
            else
                txt_PP.text = "<color=#FF3030FF>" + Player.instance.GetPlayerInfo().CurPP + "</color>/" + ConstantDefine.MAXPP;
            if (Player.instance.GetPlayerInfo().CurPP >= ConstantDefine.MAXPP)
            {
                if (recoverTimeCoroutine != null)
                {
                    StopCoroutine(recoverTimeCoroutine);
                    recoverTimeCoroutine = null;
                }
            }
        }

        IEnumerator RecoverTimeCountDown()
        {
            while (needTime > 0)
            {
                if (h >= 0 || m >= 0 || s != 0)
                {
                    s -= 1;
                    if (s < 0)
                    {
                        if (m >= 0)
                        {
                            s = 59;
                            m -= 1;
                        }
                    }
                    if (m < 0)
                    {
                        if (h > 0)
                        {
                            h -= 1;
                            m = 59;
                        }
                    }
                }
                if (h == 0)
                {
                    txt_Timer.text = Format(m) + ":" + Format(s);
                }
                else
                {
                    txt_Timer.text = Format(h) + ":" + Format(m) + ":" + Format(s);
                }
                needTime -= 1;
                //Player.instance.GetPlayerInfo().RecoverTime = needTime;
                yield return new WaitForSeconds(1.0f);
            }
            recoverTimeCoroutine = null;
            GetEnergyRequest();
        }

        private string Format(long _f)
        {
            string str = string.Empty;
            if (_f <= 9 && _f >= 0)
            {
                str = "0" + _f.ToString();
            }
            else
            {
                str = _f.ToString();
            }
            return str;
        }
        /// <summary>
        /// 抽奖表现
        /// </summary>
        private void OnDrawLotteryStart(Ivent i)
        {
            if (!isReturn)  //服务端没返回的话继续转
                return;

            //tick.Stop();
            time.Stop();
            isNeedStop = true;

            DrawLotteryHandle();
        }

        void DrawLotteryHandle()       
        {
            int itemIndex = lotteryInfo.place;

            float angleZ = (ConstantDefine.RewardItemCount - itemIndex) * (360 / ConstantDefine.RewardItemCount) + 180 / ConstantDefine.RewardItemCount;  //当前奖励的物品的位置

            Debug.Log("位置" + itemIndex + "终止角度" + angleZ + "起始角度" + img_LotteryBg.transform.eulerAngles.z);

            float offset = 360f - angleZ - img_LotteryBg.transform.eulerAngles.z;

            float totalTime = (360f - offset + lottertCircle * 360f) / (lotterySpeed * 360f);
            Debug.Log("totalTime" + totalTime);

            if (offset >= 0)
            {

                img_LotteryBg.transform.DOLocalRotate(new Vector3(0f, 0f, -(360f - offset + lottertCircle * 360f)), totalTime, RotateMode.LocalAxisAdd).SetEase(Ease.OutCirc).OnComplete(() =>
                {
                    Debug.Log("after>" + img_LotteryBg.transform.eulerAngles.z);
                    DrawLotteryOver();
                }
                );
            }

                

            else if (offset < 0)
            {
                img_LotteryBg.transform.DOLocalRotate(new Vector3(0f, 0f, -(-offset + lottertCircle * 360f)), totalTime, RotateMode.LocalAxisAdd).SetEase(Ease.OutCirc).OnComplete(() =>
                {
                    Debug.Log("after<" + img_LotteryBg.transform.eulerAngles.z);
                    DrawLotteryOver();
                }
                );
            }

            //else
            //{
            //    DrawLotteryOver();
            //}

        }

        /// <summary>
        /// 抽奖结束
        /// </summary>
        private void DrawLotteryOver()
        {
            bool isErrorItem = false;
            if (lotteryInfo != null)
            {
                switch (lotteryInfo.itemCode)
                {
                    case (int)LotteryReWardType.STAR_COIN:
                        NWarningManager.Instance.OpenPromptPanel("恭喜您获得星数金币！", 2);
                        SoundManager.Instance.PlaySound(SoundType.UISound, SoundPlayType.Only, "UI_Audio/HDJinBi");
                        ///ShowRewardPnl();
                        break;
                    case (int)LotteryReWardType.COIN:
                        Player.instance.GetPlayerInfo().CoinCount += lotteryInfo.itemCount;
                        NWarningManager.Instance.OpenPromptPanel("恭喜您获得" + lotteryInfo.itemCount + "金币！", 2);                     

                        LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.EFFECT, "Prefabs/Effect_Prefab/UI_Effect_Prefab/eff_GetGold", effect =>
                        {
                            //GameObject ps = UnityHelper.CreateObject(uiCanvas, effect, Vector3.zero, Vector3.zero, Vector3.one);
                            GameObject obj = GameObject.Instantiate(effect);
                            obj.transform.parent = uiCanvas;
                            obj.transform.localPosition = Vector3.zero;
                            obj.transform.localScale = Vector3.one;
                            Destroy(obj, 4.1f);
                        });

                        SoundManager.Instance.PlaySound(SoundType.UISound, SoundPlayType.Only, "UI_Audio/HDJinBi");
                        //ShowRewardPnl();
                        break;
                    case (int)LotteryReWardType.POWER:
                        Player.instance.GetPlayerInfo().CurPP += (int)lotteryInfo.itemCount;
                        NWarningManager.Instance.OpenPromptPanel("恭喜您获得" + lotteryInfo.itemCount + "点体力！", 2);
                        LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.EFFECT, "Prefabs/Effect_Prefab/UI_Effect_Prefab/eff_GetPower", effect =>
                        {
                            //GameObject ps = UnityHelper.CreateObject(uiCanvas, effect, Vector3.zero, Vector3.zero, Vector3.one);
                            GameObject obj = GameObject.Instantiate(effect);
                            obj.transform.parent = uiCanvas;
                            obj.transform.localPosition = Vector3.zero;
                            obj.transform.localScale = Vector3.one;
                            Destroy(obj, 2.1f);
                        });
                        SoundManager.Instance.PlaySound(SoundType.UISound, SoundPlayType.Only, "UI_Audio/HDTiLi");
                        //ShowRewardPnl();
                        break;
                    case (int)LotteryReWardType.SHIELD:
                        if (Player.instance.GetPlayerInfo().ShieldCount == 3)
                        {
                            NWarningManager.Instance.OpenPromptPanel("护盾已满！", 2);
                        }
                        else {
                            Player.instance.GetPlayerInfo().ShieldCount += (int)lotteryInfo.itemCount;
                            NWarningManager.Instance.OpenPromptPanel("恭喜您获得" + lotteryInfo.itemCount + "个护盾！", 2);

                            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.EFFECT, "Prefabs/Effect_Prefab/UI_Effect_Prefab/eff_GetShield", effect =>
                            {
                                //GameObject ps = UnityHelper.CreateObject(uiCanvas, effect, Vector3.zero, Vector3.zero, Vector3.one);
                                GameObject obj = GameObject.Instantiate(effect);
                                obj.transform.parent = uiCanvas;
                                obj.transform.localPosition = Vector3.zero;
                                obj.transform.localScale = Vector3.one;
                                Destroy(obj, 1.1f);
                            });
                        }
                        SoundManager.Instance.PlaySound(SoundType.UISound, SoundPlayType.Only, "UI_Audio/HDHuDun");
                        //ShowRewardPnl();
                        break;
                    case (int)LotteryReWardType.ATTACK:
                        isARBtnUp = true;
                        curPet.model.SetActive(false);
                        StartCoroutine(CloseUIAction("AttackUI"));
                        //OpenUIForm("AttackUI", UIFormType.Switch, UIFormShowMode.HideOther);
                        break;
                    case (int)LotteryReWardType.STEEL:
                        isARBtnUp = true;
                        curPet.model.SetActive(false);
                        StartCoroutine(CloseUIAction("Catch/CatchUI"));
                        //ShowRewardPnl();
                        break;
                    case (int)LotteryReWardType.FAMOUS_PERSON:
                        Player.instance.GetPlayerInfo().ARCount += (int)lotteryInfo.itemCount;
                        NWarningManager.Instance.OpenPromptPanel("恭喜您获得" + lotteryInfo.itemCount + "张扫描卡！", 2);
                        SoundManager.Instance.PlaySound(SoundType.UISound, SoundPlayType.Only, "UI_Audio/HDSaoMiaoK");
                        //ShowRewardPnl();
                        break;
                    case (int)LotteryReWardType.SCAN:
                        NWarningManager.Instance.OpenPromptPanel("恭喜您获得" + lotteryInfo.itemCount + "张装扮解锁扫描卡！", 2);
                        SoundManager.Instance.PlaySound(SoundType.UISound, SoundPlayType.Only, "UI_Audio/HDSaoMiaoK");                  
                        //ShowRewardPnl();
                        break;
                    default:
                        //Debug.LogError("itemcode not define!");
                        isErrorItem = true;
                        break;
                }

            }
            else {
                //Debug.LogError("lotteryInfo is null!");
                isErrorItem = true;
            }
           
            if (isErrorItem)
                NWarningManager.Instance.OpenPromptPanel("没有该奖励物品CODE！", 2);

            GetEnergyRequest();
            ResetLotteryParam();

            if (!isARBtnUp)
                StartLotteryBtnCallback();
        }
        /// <summary>
        /// 重置转盘相关操作
        /// </summary>
        private void ResetLotteryParam()
        {
            ARGameState.Instance.isLotterying = false;
            isNeedStop = true;
            isReturn = false;
            lotteryInfo = null;
        }
        

        void ShowRewardPnl()
        {
            //Pnl_Reward.gameObject.SetActive(true);

            //LoadBundleResMgr.Instance.LoadAssetbund<Texture2D>(NResourceType.ICON, "Textures/Lottery/" + lotteryInfo.itemCode.ToString(), icon =>
            //{                
            //    img_Reward.sprite = Sprite.Create(
            //    icon,
            //    new Rect(0, 0, icon.width, icon.height),
            //    new Vector2(0.5f, 0.5f));
            //});
            
            //txt_RewardCount.text = "+" + lotteryInfo.itemCount;
            OpenUIForm("LotteryRewardUI", UIFormType.Switch, UIFormShowMode.Overlay);

        }
        /// <summary>
        /// 抽奖错误处理
        /// </summary>
        private void OnDrawLotteryError()
        {
            ResetLotteryParam();
            //tick.Stop();
            NWarningManager.Instance.OpenDialogPanel("抽奖异常", null);
        }

        #region 消息部分
        /// <summary>
        /// 抽奖
        /// </summary>
        private void DrawLotteryRequest()
        {
            string _param = "{}";
            NetManager.instance.Request(MsgEventType.DRAW_LOTTERY, _param);
        }
        /// <summary>
        /// 抽奖结果返回
        /// </summary>
        /// <param name="_jsonStr"></param>
        private void DrawLotteryCallBack(string _jsonStr)
        {
            Debug.Log("OnDrawLottery：" + _jsonStr);
            //_jsonStr = "{\"item\":" + 102 + ",\"count\":" + 10 + ",\"place\":" + 10 + ",\"pp\":" + 49 + ",\"last_pp_regain\":" + 1000 + "}";
            JsonData _json = JsonMapper.ToObject(_jsonStr);
            if (((IDictionary)_json).Contains("code"))
            {
                NWarningManager.Instance.OpenErrorCode(_json["code"].ToJson().Replace("\"", ""), 2);
                //switch (int.Parse(_json["code"].ToJson().Replace("\"", "")))
                //{
                //    case 1:
                //        NWarningManager.Instance.OpenDialogPanel("错误：未知错误", null);
                //        break;
                //    case 42:
                //        NWarningManager.Instance.OpenDialogPanel("错误：当前体力值不足", null);
                //        break;
                //    case 90001:
                //        NWarningManager.Instance.OpenDialogPanel("错误：网络断开", null);
                //        break;
                //    default:
                //        NWarningManager.Instance.OpenDialogPanel("错误：未收录错误码", null);
                //        break;
                //}
                //错误处理
                OnDrawLotteryError();
            }
            else
            {  
                int curPP = int.Parse(_json["pp"].ToJson().Replace("\"", ""));
                Player.instance.GetPlayerInfo().CurPP -= 1;

                lotteryInfo = new LotteryInfo();
                lotteryInfo.itemCode = int.Parse(_json["item"].ToJson().Replace("\"", ""));
                lotteryInfo.itemCount = long.Parse(_json["count"].ToJson().Replace("\"", ""));
                lotteryInfo.place = int.Parse(_json["place"].ToJson().Replace("\"", ""));


                //体力恢复时间间隔相关
                //Debug.Log("last_pp_regain====" + int.Parse(_json["last_pp_regain"].ToJson().Replace("\"", "")));
                Player.instance.GetPlayerInfo().RecoverTime = 3600 - int.Parse(_json["last_pp_regain"].ToJson().Replace("\"", ""));


                //客户端抽奖   
                isReturn = true;
            }
        }
        /// <summary>
        /// 请求体力和恢复时间间隔
        /// </summary>
        private void GetEnergyRequest()
        {
            string _param = "{}";
            NetManager.instance.Request(MsgEventType.GET_ENERGY, _param);
        }
        /// <summary>
        /// 请求体力和恢复时间间隔返回
        /// </summary>
        private void GetEnergyRequestCallBack(string _jsonStr)
        {
            //Debug.Log("GetEnergyRequestCallBack：" + _jsonStr);
            JsonData _json = JsonMapper.ToObject(_jsonStr);
            if (((IDictionary)_json).Contains("code"))
            {
              
            }
            else
            {
                int curPP = int.Parse(_json["pp"].ToJson().Replace("\"", ""));
                int last_pp_regain = int.Parse(_json["last_pp_regain"].ToJson().Replace("\"", ""));

                Player.instance.GetPlayerInfo().CurPP = curPP;
                Player.instance.GetPlayerInfo().RecoverTime = 3600 - last_pp_regain;
            }
        }
        #endregion
        
    }
}
