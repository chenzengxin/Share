﻿using UnityEngine.UI;
using UnityEngine;
using ND.Game.BusinessFramework;
using ND.ARGame.Data;
using ND.ARGame.Login;

namespace ND.Game.UILogic
{

    public class PetListUI : UIMonoSingleton<PetListUI>
    {

        private const string BoardUIPath = "UI/Prefabs/Pet/PetListUI_board";
        private const string CellUIPath = "UI/Prefabs/Pet/PetListUI_cell";
        private const string IconResPath = "UI/Icon/MonsterIcon/";

        private const int ColumnCount = 3;
        private const int MinRowCount = 4;

        private Transform content;

        public override void OnInit()
        {
            RigisterButtonObjectEvent("BackButton",OnBackButtonClick);
            content = transform.Find("ScrollRect/Viewport/Content");
        }

        public override void RedisplayInit()
        {
            PetUIData.RefreshData();
            InitContent();
        }

        public override void OnAfterHide()
        {
            for(int i=0;i<content.childCount;i++)
            {
                UnityHelper.Destroy(content.GetChild(i).gameObject);
            }
        }

        private void OnBackButtonClick(GameObject go)
        {
            if (PetUIData.isPassToOpenList || Player.instance.GetPlayerInfo().CurrentCultivatePetId == "0")
            {
                Player.instance.GetPlayerInfo().CurrentCultivatePetId = "0";
                CloseUIFormsByName("PetCultivateUI");
                ARGameMainUI.Instance.SetAddPetBtn(true);
                PetUIData.isPassToOpenList = false;
            }

            CloseUIForm();
        }

        private void InitContent()
        {
            int count = PetUIData.PetList.Count;
            int remainFactor = count % ColumnCount;
            int multiFactor = count / ColumnCount;
            int index = 0;
            int instantiateCount = remainFactor == 0 ? multiFactor : multiFactor + 1;
            instantiateCount = Mathf.Clamp(instantiateCount, MinRowCount, instantiateCount);

            for (int i = 0; i < instantiateCount; i++)
            {
                int childCount = multiFactor > 0 ? ColumnCount : (multiFactor == 0 ? remainFactor : 0);
                childCount = Mathf.Clamp(childCount, 0, childCount);
                InstantiateBoard(childCount, index);
                multiFactor--;
                index += childCount;
                index = Mathf.Clamp(index, 0, count - 1);
            }
        }

        private void InstantiateBoard(int childCount, int dataIndex)
        {
            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.UI, BoardUIPath, boardRes =>
            {
                GameObject go = UnityHelper.CreateUIObject(content, boardRes);

                for (int i = 0; i < childCount;i++ )
                {
                    InstantiatePetCell(go.transform, PetUIData.PetList[dataIndex+i]);
                }
            });      
        }

        private void InstantiatePetCell(Transform parent, CultivatePet data)
        {
            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.UI, CellUIPath, cellRes =>
            {
                Transform tran = UnityHelper.CreateUIObject(parent, cellRes).transform;

                UnityHelper.FindTheChildNode(tran,"Name").GetComponent<Text>().text=data.petName;
                bool isComplete = data.iSComplete == 1 ? true : false;
                UnityHelper.FindTheChildNode(tran, "Flag").gameObject.SetActive(isComplete);

                LoadBundleResMgr.Instance.LoadAssetbund<Sprite>(NResourceType.ICON, IconResPath + data.petCode, icon => 
                {
                    Transform iconTran = UnityHelper.FindTheChildNode(tran, "Icon");

                    RigisterButtonObjectEvent(iconTran, (go) => { PetUIData.OnPetCellClick(go, () => { OpenUIForm("Pet/PetDetailUI", UIFormType.Switch, UIFormShowMode.HideOther); }); });
                    iconTran.GetComponent<Image>().sprite = icon;
                    iconTran.name = data.petId;
                });

            });
           
        }
    }
}

