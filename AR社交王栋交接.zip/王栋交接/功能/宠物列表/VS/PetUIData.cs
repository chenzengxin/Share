﻿using UnityEngine;
using System;
using System.Linq;
using ND.ARGame.Login;
using System.Collections.Generic;

namespace ND.ARGame.Data
{
    public class PetUIData
    {
        public static bool isMyHome = true;
        public static bool isPassToOpenList = false;
        public static List<CultivatePet> PetList = new List<CultivatePet>();
        public static CultivatePet currentPetData = null;
        private const int PetCount = 15;

        public static void RefreshData()
        {
            Dictionary<string, CultivatePet> petDictionary = Player.instance.GetPlayerInfo().petDictionary;
            PetList.Clear();
            foreach (var data in petDictionary)
            {
                if (data.Value.petIndex == 0)
                {
                    PetList.Add(data.Value);
                }
            }
            PetList.Sort(new SortInAscendingOrder());
        }

        public static void OnPetCellClick(GameObject go,Action Function)
        {
            foreach (var data in PetList)
            {
                if (data.petId == go.name)
                {
                    currentPetData = data;
                    Function();
                    break;
                }
            }
        }

        public static void ForTest()
        {
            PetList.Clear();

            for (int i = 1; i <= PetCount; i++)
            {
                CultivatePet pet = new CultivatePet();
                pet.petCode = 30000 + i;
                pet.petName = i.ToString();
                pet.petId = i.ToString();
                pet.haeGlass = 1;
                PetList.Add(pet);
            }
            currentPetData = PetList[0];
        }

        public static int SortData(out List<CultivatePet> culList, out List<CultivatePet> unCulList)
        {
            Dictionary<CultivatePet, int> cultivateDictionary = new Dictionary<CultivatePet, int>();
            Dictionary<int, CultivatePet> unCultivateDictionary = new Dictionary<int, CultivatePet>();

            int completedCount = 0;
            foreach (var data in PetList)
            {
                completedCount += data.iSComplete;
                if (data.petIndex != 0 && data.iSComplete == 1)
                {
                    cultivateDictionary.Add(data,data.petCode);
                }
                else if (!unCultivateDictionary.ContainsKey(data.petCode))
                {
                    unCultivateDictionary.Add(data.petCode, data);
                }
            }

            for (int i = 1; i <= PetCount; i++)
            {
                if (!cultivateDictionary.ContainsValue(i) && !unCultivateDictionary.ContainsKey(i))
                {
                    CultivatePet data = new CultivatePet();
                    data.petCode = i;
                    data.petIndex = i;
                    unCultivateDictionary.Add(i, data);
                }
            }

            culList = cultivateDictionary.Keys.ToList();
            unCulList = unCultivateDictionary.Values.ToList();
            culList.Sort(new SortInAscendingOrder());
            unCulList.Sort(new SortInAscendingOrder());

            return completedCount;
        }
    }

    public class SortInAscendingOrder : IComparer<CultivatePet>
    {
        public int Compare(CultivatePet x, CultivatePet y)
        {
            if (x.petIndex != 0 && y.petIndex != 0)
            {
                return x.petIndex - y.petIndex;
            }
            else if(x.petIndex==0&&y.petIndex!=0)
            {
                return 1;
            }
            else if(x.petIndex!=0&&y.petIndex==0)
            {
                return -1;
            }
            else
            {
                return x.petCode - y.petCode;
            }
        }
    }

}
