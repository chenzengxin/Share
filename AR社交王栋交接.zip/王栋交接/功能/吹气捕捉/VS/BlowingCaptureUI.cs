﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using ND.ARGame.Data;
using ND.Events;
using ND.Game.BusinessFramework;
using ND.Game.GameLogic;
using ND.Utils;
using LitJson;
using System.Collections;
using ND.ARGame.Net;
using ND.ARGame.Define;
using ND.ARGame.Login;
using ND.ARGame.Manager;
using DG.Tweening;

namespace ND.Game.UILogic
{
    public class BlowingCaptureUI : UIMonoSingleton<BlowingCaptureUI>
    {

        private const float MinStartSpeed = 0.05f;
        private const float MaxStartSpeed = 10f;
        private const float MinRate = 0f;
        private const float MaxRate = 20f;

        private const string ModelPath = "UI/Prefabs/Capture/";

        private GameObject blowingCaptureModel;
        private Tick tick;

        private ParticleSystem fogEffect;
        private Transform startTip;
        private Transform noEnoughTip;
        private AudioClip clip;
        private float waitTime = 0.4f;
        private float volume;
        private float disperseVolume = 0.5f;
        private bool isEnableDisperse = false;

        public Callback<bool> OnCaptureEnd;

        public override void RedisplayInit()
        {

            LoadBundleResMgr.Instance.LoadAssetbund<GameObject>(NResourceType.MODEL, ModelPath + "BlowingCaptureModel", go =>
            {
                blowingCaptureModel = GameObject.Instantiate(go);
                fogEffect = blowingCaptureModel.transform.FindChild("FogCanvas/eff_EvilFog/eff_EvilFog").GetComponent<ParticleSystem>();
            });

            startTip = UnityHelper.FindTheChildNode(transform, "TopTip/StartTip");
            noEnoughTip = UnityHelper.FindTheChildNode(transform, "TopTip/NoEnoughTip");
            clip = Microphone.Start("Built-in Microphone", true, 10, 44100);

            tick = new Tick();
            tick.AddEventListener(Ivent.TICK, HandleBlowingEvent);
            tick.Start();
        }

        private void HandleBlowingEvent(Ivent t)
        {
            //waitTime = UnityHelper.FindTheChildNode(transform, "Slider").GetComponent<Slider>().value;
            //UnityHelper.FindTheChildNode(transform, "Value").GetComponent<Text>().text = waitTime.ToString();
            //disperseVolume = UnityHelper.FindTheChildNode(transform, "Slider1").GetComponent<Slider>().value;
            //UnityHelper.FindTheChildNode(transform, "Value1").GetComponent<Text>().text = disperseVolume.ToString();

#if UNITY_EDITOR

            if (Input.GetMouseButton(0))
            {
                volume += 0.01f;
            }
            else
            {
                volume -= 0.01f;
            }
#elif UNITY_ANDROID
            volume = GetVolume();
            volume *= volume;
#endif

            volume = Mathf.Clamp(volume, 0, 1);
            Debug.Log(volume);

            fogEffect.startSpeed = MinStartSpeed + volume * (MaxStartSpeed - MinStartSpeed);
            fogEffect.emissionRate = MaxRate - volume * (MaxRate - MinRate);

            if (volume < 0.2f)
            {
                startTip.gameObject.SetActive(true);
                noEnoughTip.gameObject.SetActive(false);
            }
            else
            {
                startTip.gameObject.SetActive(false);
                noEnoughTip.gameObject.SetActive(true);
            }

            if (volume >= disperseVolume)
            {
                if (!isEnableDisperse)
                {
                    StartCoroutine(DisperseFog());
                    isEnableDisperse = true;
                }
            }
            else if (isEnableDisperse)
            {
                StopAllCoroutines();
                isEnableDisperse = false;
            }
        }

        private IEnumerator DisperseFog()
        {
            yield return new WaitForSeconds(waitTime);

            tick.Stop();
            isEnableDisperse = false;
            Microphone.End("Built-in Microphone");
            noEnoughTip.gameObject.SetActive(false);
            fogEffect.startSpeed = MaxStartSpeed;
            fogEffect.emissionRate = MinRate;

            yield return new WaitForSeconds(3);
            CloseUIForm();
            if(OnCaptureEnd!=null)
            {
                OnCaptureEnd(true);
            }
        }

        private float GetVolume()
        {
            if (clip == null)
            {
                Debug.Log("NULL Microphone");
                return 0;
            }

            // 采样数
            int sampleSize = 128;
            float[] samples = new float[sampleSize];
            int startPosition = Microphone.GetPosition(null) - (sampleSize + 1);
            // 得到数据
            clip.GetData(samples, startPosition);

            float levelMax = 0;
            float levelAverage = 0;
            for (int i = 0; i < sampleSize; ++i)
            {
                float wavePeak = samples[i];
                if (levelMax < wavePeak)
                    levelMax = wavePeak;
                levelAverage += samples[i];
            }
            levelAverage /= sampleSize;

            return levelMax;
        }
    }
}
