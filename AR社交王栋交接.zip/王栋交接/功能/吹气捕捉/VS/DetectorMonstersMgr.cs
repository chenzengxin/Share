﻿/************************************************************************* 
文件：		DetectorMonstersMgr.cs
日期：		2017/2/22
时间：		14 : 33
版本：		v1.0
作者：		陈增鑫
说明：      检测场景宠物管理类
*************************************************************************/
using UnityEngine;
using System.Collections.Generic;
using DG.Tweening;
using System.Linq;
using LitJson;

using ND.ARGame.Define;
using ND.Game.UILogic;
using System.Collections;
using System;
using ND.ARGame.Config;
using ND.ARGame.Manager;
using ND.Utils;
using ND.Events;
using ND.Game.BusinessFramework;
using ND.ARGame.Data;
using ND.ARGame.Login;
using ND.ARGame.GameLogic;
using ND.ARGame.Tools;

namespace ND.Game.GameLogic
{
    public class DetectorMonstersMgr : TMonoSingleton<DetectorMonstersMgr>
    {
        public delegate void OnQTEValueChanged(float value);


        #region 对象
        private ParticleSystem successPs;
        private ParticleSystem screenOutPs;
        private ParticleSystem hitPs;
        private ParticleSystem fingerMovePs;
        private GameObject catchSuccessPs;
        private ParticleSystem qteRightHint;
        private ParticleSystem qteManipulateHint;
        

        private AbstactCapture abstractCapture;
        private ViewCamera viewCamera;
        private Camera realityCam;


        //private AudioSource audioSourceBG;      //播放背景音乐
        private AudioSource audioSourceOnce;    //播放一次性音乐

        #region 音效对象
        //public AudioClip bubbleAudio;
        //public AudioClip btnClickAudio;
        //public AudioClip detectorBGAudio;
        //public AudioClip detectorSucceedAudio;//扫描的的音效
        //public AudioClip detectorFailedAudio;//扫描后出不了怪或者体力小于5
        //public AudioClip[] climpOutAudio;   //头冒出的音效（嘴巴张开，宠物冒出、屏幕钻出）
        //public AudioClip petRelease;
        //public AudioClip petCatchAudio;//嘴巴互动手指点到宠物屁股的声音
        //public AudioClip[] captureSucceedAudio;//捕捉成功的音效
        //public AudioClip[] captureFailedAudio;//宠物逃跑的音效
        ////public AudioClip createMonsterAudio;
        //public AudioClip dragSucceedAudio;   //qte拎到指定位置的音效
        //public AudioClip[] petAngryAudios; //QTE时候播放的喷怒音效，随机调用
        //public AudioClip[] petDragAudios; //屏幕：宠物被拎着的时候循环播放，随机调用
        //public AudioClip fingerSucceedAudio;    //qte正确操作的音效
        //public AudioClip fingerFailedAudio;     //qte错误操作的音效

        #endregion

        #endregion

        #region 变量
        private CultivatePet curPet;
        private int showWay;
        private GetFaceDataFromAndroid getFaceDataFromAndroid;
        //private List<GameObject> monsterPrefabs;
        private Timer timer;
        //private Camera modelCamera;
        #endregion


#if UNITY_EDITOR
        void Update()
        {
            if (Input.GetKeyDown(KeyCode.D))
            {
                MatchPetCallback("{\"pet_id\":3051,\"pet_code\":30005,\"scan_face_count\":1984,\"has_glass\":1}");
            }
        }

        //void Start()
        //{

        //    ND.Game.GameLogic.DrawSymbol.instance.Init();
        //}
#endif


        public void Init()
        {
            EventCenter.AddListener<string>(MsgEventType.CAPTURE_PET, CapturePetCallback);
            EventCenter.AddListener<string>(MsgEventType.MATCHP_PET, MatchPetCallback);
            EventCenter.AddListener<string>(MsgEventType.GET_MATCH_COUNT, GetMatchCountCallback);

            InitReference();

            getFaceDataFromAndroid = this.gameObject.GetComponent<GetFaceDataFromAndroid>();
            if (getFaceDataFromAndroid == null)
            {
                getFaceDataFromAndroid = this.gameObject.AddComponent<GetFaceDataFromAndroid>();
            }
            getFaceDataFromAndroid.onFaceUpdate += CheckFacePos;
          
            viewCamera = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Scene_Prefab/ViewCamera")).AddComponent<ViewCamera>();
            viewCamera.transform.rotation = Quaternion.identity;
            getFaceDataFromAndroid.target = viewCamera.transform;
            getFaceDataFromAndroid.IsNeedRefresh = true;

            CameraHandler.instance.onChangeCamera = viewCamera.SetView;
            ND.Game.BusinessFramework.UIManager.Instance.ShowUIForms("DetectorUI", UIFormType.Switch, UIFormShowMode.Main);
            DetectorUI.Instance.SetInitView();

            JsonData data = new JsonData();
            data.SetJsonType(JsonType.Object);
            ND.ARGame.Net.NetManager.instance.Request(MsgEventType.GET_MATCH_COUNT, data.ToJson());

            //InitAudio();
        }

        /// <summary>
        /// 场景初始化
        /// </summary>
        void InitReference()
        {
            this.realityCam = new GameObject("RealityCam").AddComponent<Camera>();
            this.realityCam.transform.localPosition = Vector3.back * 20;
            this.realityCam.orthographic = true;
            this.realityCam.orthographicSize = 6.4f;
            this.realityCam.depth = -1;
            this.realityCam.cullingMask = (1 << (LayerMask.NameToLayer("AR"))) + (1 << (LayerMask.NameToLayer("Reality")));
            this.realityCam.clearFlags = CameraClearFlags.Depth;
            this.realityCam.gameObject.AddComponent<AudioListener>();

            #region ParticleSystem
            this.screenOutPs = Resources.Load<ParticleSystem>("Prefabs/Effect_Prefab/eff_Pu");
            this.fingerMovePs = Resources.Load<ParticleSystem>("Prefabs/Effect_Prefab/eff_FingerMoveTrailing");
            this.successPs = Resources.Load<ParticleSystem>("Prefabs/Effect_Prefab/effect_scanning_01");
            this.catchSuccessPs = Resources.Load<GameObject>("Prefabs/Effect_Prefab/SuccessBeforeShow");
            this.hitPs = Resources.Load<ParticleSystem>("Prefabs/Effect_Prefab/eff_Hit");
            this.qteManipulateHint = Resources.Load<ParticleSystem>("Prefabs/Effect_Prefab/eff_ManipulateHint");
            this.qteRightHint = Resources.Load<ParticleSystem>("Prefabs/Effect_Prefab/eff_QTERightHint");
            //this.detectorFingers = Resources.LoadAll<GameObject>("Prefabs/UI_Prefab");

           

            #endregion 

            //monsterPrefabs = Resources.LoadAll<GameObject>(PathDefine.rolePrefabPath).ToList();
          
            #region clip
            //this.btnClickAudio = Resources.Load<AudioClip>("Audios/UI_Audio/OnClick/UI_click_general");
            //this.bubbleAudio = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/UI_PASV_bubble");
            //this.detectorSucceedAudio = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/UI_PASV_CPM_scan_successful");
            //this.detectorFailedAudio = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/UI_PASV_CPM_scan_unsuccessful");
            //this.climpOutAudio = Resources.LoadAll<AudioClip>("Audios/Scene_Audio/Face/ClimbOut");
            //this.petCatchAudio = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/UI_ACT_pet_catch");
            //this.petRelease = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/UI_ACT_pet_release");
            //this.captureSucceedAudio = Resources.LoadAll<AudioClip>("Audios/Scene_Audio/Face/CaptureSucceed");
            //this.captureFailedAudio = Resources.LoadAll<AudioClip>("Audios/Scene_Audio/Face/CaptureFailed");
            //this.dragSucceedAudio = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/DragSucceed/UI_tuozhuai_successful");
            //this.petAngryAudios = Resources.LoadAll<AudioClip>("Audios/Scene_Audio/Face/Angry");
            //this.petDragAudios = Resources.LoadAll<AudioClip>("Audios/Scene_Audio/Face/Catch");
            //this.fingerSucceedAudio = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/FingerSucceed/vox_QTE_slide");
            //this.fingerFailedAudio = Resources.Load<AudioClip>("Audios/Scene_Audio/Face/FingerFailed/UI_QTE_unsuccessful");
            #endregion

        }
        /// <summary>
        /// 音效初始化
        /// </summary>
        //void InitAudio()
        //{

        //    if (audioSourceBG == null)
        //    {
        //        audioSourceBG = new GameObject("BG").AddComponent<AudioSource>();
        //    }
        //    audioSourceBG.clip = detectorBGAudio;
        //    audioSourceBG.loop = true;
        //    if (audioSourceOnce == null)
        //    {
        //        audioSourceOnce = new GameObject("AudioOnce").AddComponent<AudioSource>();
        //        audioSourceOnce.playOnAwake = false;
        //    }

        //    foreach (var item in DetectorUI.Instance.GetButtons())
        //    {
        //        item.onClick.AddListener(() =>
        //        {
        //            audioSourceOnce.Stop();
        //            audioSourceOnce.clip = btnClickAudio;
        //            audioSourceOnce.Play();
        //        });
        //    }
        //}

        #region 服务端请求回调
        /// <summary>
        /// 匹配宠物
        /// </summary>
        private void MatchPetCallback(string message)
        {
            LogManager.DebugLog("MatchPetCallback: " + message);

            try
            {
                JsonData data = JsonMapper.ToObject(message);

                if (((IDictionary)data).Contains("err_msg"))
                {
                    int code = int.Parse(data["code"].ToJson());

                    #region 错误码解析
                    switch (code)
                    {
                        case 90001:
                            NWarningManager.Instance.OpenDialogPanel(
                                ErrorCodeRemind.Instance.GetDesc(data["err_msg"].ToJson().Replace("\"", "")), () =>
                                {
                                    LoginManager.instance.LogOut();
                                });
                            break;
                        default:
                            NWarningManager.Instance.OpenDialogPanel(
                                ErrorCodeRemind.Instance.GetDesc(data["err_msg"].ToJson().Replace("\"", "")), () =>
                                {
                                    OnExit();
                                    
                                    SceneLoadManager.Instance.LoadSceneAsync("Face");
                                });
                            break;
                    }
                    #endregion
                }
                else
                {

                    curPet = new CultivatePet();

                    curPet.petId = data["pet_id"].ToJson().Replace("\"", "");
                    curPet.petCode = int.Parse(data["pet_code"].ToJson().Replace("\"", ""));

                    if (((IDictionary)data).Contains("has_glass"))
                        curPet.haeGlass = int.Parse(data["has_glass"].ToJson().Replace("\"", ""));

                    Player.instance.GetPlayerInfo().ARCount = int.Parse(data["scan_face_count"].ToJson().Replace("\"", ""));
                    curPet.petName = MonsterConfigMgr.instance.GetConfig((curPet.petCode).ToString()).name;
                    curPet.murmur = MonsterConfigMgr.instance.GetConfig((curPet.petCode).ToString()).murmur;

                    DetectorUI.Instance.SetEnergy(Player.instance.GetPlayerInfo().ARCount.ToString());
                    CreateMonster();
                }
            }
            catch (Exception e)
            {
                LogManager.DebugLog("matchPet网络数据异常" + e.Message.ToString());
                 NWarningManager.Instance.OpenDialogPanel("网络数据异常，退出重试", delegate
                {
                    OnExit();
                    SceneLoadManager.Instance.LoadSceneAsync("Face");
                });
            }
        }

        /// <summary>
        /// 捕捉宠物，服务端校验
        /// </summary>
        private void CapturePetCallback(string message)
        {
            LogManager.DebugLog("CapturePetCallback: " + message);
            try
            {
                JsonData data = JsonMapper.ToObject(message);
                int code = int.Parse(data["code"].ToJson().Replace("\"", ""));
                #region 错误码解析
                switch (code)
                {
                    case 0:
                        SucceedShowing();
                        Player.RequestGetPetList();
                        break;
                    case 8:
#if UNITY_EDITOR
                        SucceedShowing();
                        Player.RequestGetPetList();
#elif UNITY_ANDROID
                        NWarningManager.Instance.OpenDialogPanel(
                            ErrorCodeRemind.Instance.GetDesc(data["err_msg"].ToJson().Replace("\"", "")), () =>
                            {
                                OnExit();
                                SceneLoadManager.Instance.LoadSceneAsync("Face");
                            });
#endif
                        break;
                    case 90001:
                        NWarningManager.Instance.OpenDialogPanel(
                            ErrorCodeRemind.Instance.GetDesc(data["err_msg"].ToJson().Replace("\"", "")), () =>
                            {
                                LoginManager.instance.LogOut();
                            });
                        break;
                    default:
                        NWarningManager.Instance.OpenDialogPanel(
                            ErrorCodeRemind.Instance.GetDesc(data["err_msg"].ToJson().Replace("\"", "")), () =>
                            {
                                OnExit();
                                SceneLoadManager.Instance.LoadSceneAsync("Face");
                            });
                        break;
                #endregion
                }
            }
            catch (Exception e)
            {
                LogManager.DebugLog("matchPet网络数据异常" + e.Message.ToString());
                NWarningManager.Instance.OpenDialogPanel("网络数据异常,退出重试", delegate
                {
                    OnExit();
                    SceneLoadManager.Instance.LoadSceneAsync("Face");
                });
            }
        }

        /// <summary>
        /// 获取玩家剩余扫描次数回调
        /// </summary>
        private void GetMatchCountCallback(string message)
        {
            print(message);
            try
            {
                JsonData data = JsonMapper.ToObject(message);

                if (((IDictionary)data).Contains("err_msg"))
                {
                    int code = int.Parse(data["code"].ToJson());

                    #region 错误码解析
                    switch (code)
                    {
                        case 90001:
                            NWarningManager.Instance.OpenDialogPanel(
                                ErrorCodeRemind.Instance.GetDesc(data["err_msg"].ToJson().Replace("\"", "")), () =>
                            {
                                LoginManager.instance.LogOut();
                            });
                            break;
                        default:
                            NWarningManager.Instance.OpenDialogPanel(
                                ErrorCodeRemind.Instance.GetDesc(data["err_msg"].ToJson().Replace("\"", "")), () =>
                      {
                          OnExit();
                          SceneLoadManager.Instance.LoadSceneAsync("Face");
                      });
                            break;
                    }
                    #endregion
                }
                else
                {
                    int matchCount = int.Parse(data["scan_face_count"].ToJson().Replace("\"", ""));

                    DetectorUI.Instance.SetEnergy(matchCount.ToString());

                    if (matchCount < 0)
                    {
                        //PlayOnceAudioClip(detectorFailedAudio);
                         NWarningManager.Instance.OpenDialogPanel("扫描次数不够了!", ()=>
                        {
                            OnExit();
                            SceneLoadManager.Instance.LoadSceneAsync("GameMain");
                        });
                    }
                    else
                    {
                        CameraHandler.instance.SelectCamera(CameraHandler.instance.IsFrontFacing);
                    }
                }
            }
            catch (Exception e)
            {
                LogManager.DebugLog("matchPet网络数据异常" + e.Message.ToString());
                NWarningManager.Instance.OpenDialogPanel("网络数据异常，退出重试", ()=>
                {
                    OnExit();
                    SceneLoadManager.Instance.LoadSceneAsync("Face");
                });
            }
        }
        #endregion
        /// <summary>
        /// 捕捉成功分享显示
        /// </summary>
        private void SucceedShowing()
        {
            DetectorUI.Instance.SetDefault();
            
            //PlayOnceAudioClip(captureSucceedAudio);
            timer = new Timer(1, 1);
            timer.AddEventListener(TimerEvent.TIMER, ShowCatchPetInfo);
            timer.Start();

            //if (showWay != 3)
            //{
            //    GameObject go = Instantiate(this.catchSuccessPs);
            //    Destroy(go, 3);
            //}
           
        }
        /// <summary>
        /// 刷新宠物信息
        /// </summary>
        /// <param name="i"></param>
        private void ShowCatchPetInfo(Ivent i)
        {
            //if (curPet.model == null)
            //{
            //    curPet.model = Instantiate(monsterPrefabs[curPet.petCode - 1]).gameObject;
            //    curPet.model.transform.position = new Vector3(0, -1.7f, -5);
            //    curPet.model.transform.rotation = Quaternion.Euler(0, 180, 0);
            //    curPet.model.transform.localScale = Vector3.one * 5.5f;
            //}
          //  DetectorUI.Instance.SetFaceMaskShow(true);
            //DetectorUI.Instance.RefreshUIInfo(curPet.petName, curPet.murmur);

            DetectorUI.Instance.RefreshUIInfo(curPet);
        }

        /// <summary>
        /// 根据服务端code生成对应宠物
        /// </summary>
        private void CreateMonster()
        {
            //DetectorUI.Instance.SetFaceMaskShow(false);
            DetectorUI.Instance.ShowCircle(false);
            DetectorUI.Instance.SetRectState(false);

            if (curPet.model != null)
            {
                DestroyImmediate(curPet.model);
                curPet.model = null;
            }

            //showWay = UnityEngine.Random.Range(0, 3);
            showWay = 3;

            CaptureType(showWay);
        }

        /// <summary>
        /// 重新生成宠物开始捕捉
        /// </summary>
        private void RestartCreateMonster()
        {
            //一定概率回到初始状态，
            float p = UnityEngine.Random.Range(0, 10.0f);

            if (curPet.model != null)
            {
                DestroyImmediate(curPet.model);
                curPet.model = null;
            }

            if (p > 5)
            {
                CaptureType(this.showWay);
            }
            else
            {
                CaptureFail();
            }
        }

        /// <summary>
        /// 捕捉方式
        /// </summary>
        private void CaptureType(int way)
        {
            //curPet.model = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Role_Prefab/Park/"
            //                                     + curPet.petCode + "/Normal")) as GameObject;
            //modelCamera = curPet.model.GetComponentInChildren<Camera>();
            
            //if (curPet.haeGlass==1)
            //{
            //    GameObject glasses = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Role_Prefab/Props_Prefab/Glasses_" + 1));
            //        //UnityEngine.Random.Range(1, 3)));

            //    glasses.transform.SetParent(GameObject.FindGameObjectWithTag("Head").transform);
            //    glasses.transform.localRotation = Quaternion.identity;
            //    glasses.transform.localPosition = Vector3.zero;
            //    glasses.transform.localScale = Vector3.one;
            //}
            //CultivatePet pet = new CultivatePet();
            MainSceneInit.instance.SceneInit(ref curPet);
            if (curPet.camera != null)
                curPet.camera.enabled= false;

            switch (way)
            {
                case 0:
                    abstractCapture = new MouthCapture(curPet.model,
                        hitPs,
                        DetectorUI.Instance.GetTimer(),
                        0.067f,
                        CaptureEnd,
                        getFaceDataFromAndroid);

                    abstractCapture.StartCapture();
                    break;

                case 1:
                    abstractCapture = new ScreenCapture(curPet.model,
                        realityCam,
                        screenOutPs,
                        fingerMovePs,
                        qteRightHint,
                        hitPs,
                        qteManipulateHint,
                        DetectorUI.Instance.GetTimer(),
                        0.2f,
                        CaptureEnd);
                    abstractCapture.StartCapture();
                    break;

                case 3:
                    abstractCapture = new SymbolCapture(curPet,
                        realityCam,
                        getFaceDataFromAndroid,
                        viewCamera.gameObject,
                        0.2f,
                        CaptureEnd);
                    abstractCapture.StartCapture();
                    break;
                case 4:
                    abstractCapture = new BlowingCapture(curPet.model, viewCamera.gameObject, 0.2f, CaptureEnd);
                    abstractCapture.StartCapture();
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 捕捉结束
        /// </summary>
        private void CaptureEnd(bool result)
        {
            if (result)
            {
                CaptureSucceed();
            }
            else
            {
                CoroutineHelper.DoStartCoroutine(StartCoroutineWait(2f, RestartCreateMonster));
            }
        }

        /// <summary>
        /// 捕获成功，请求服务器
        /// </summary>
        void CaptureSucceed()
        {
            //if (showWay !=3&&curPet.model != null)
            //    Destroy(curPet.model.gameObject);

            if (curPet.camera != null)
                curPet.camera.enabled = true;
            curPet.model.transform.parent = null;
            curPet.model.transform.localScale = Vector3.one;
            curPet.model.transform.localPosition = Vector3.zero;
            curPet.model.transform.localEulerAngles = Vector3.zero;


            JsonData data = new JsonData();
            data.SetJsonType(JsonType.Object);
            data["pet_id"] = curPet.petId;
            ND.ARGame.Net.NetManager.instance.Request(MsgEventType.CAPTURE_PET, data.ToJson());
        }
        /// <summary>
        /// 捕获失败，重新开始
        /// </summary>
        void CaptureFail()
        {
            Debug.Log("CaptureFail");
            //PlayOnceAudioClip(this.captureFailedAudio[UnityEngine.Random.Range(0, captureFailedAudio.Length)]);
            NWarningManager.Instance.OpenDialogPanel("宠物溜走啦，请重新开始", delegate
            {
                OnExit();
                SceneLoadManager.Instance.LoadSceneAsync("Face");
            });
        }


        void OnDestroy()
        {
            OnExit();
        }

        public void OnExit()
        {
            if (timer != null)
                timer.ClearEventListener();
            EventCenter.RemoveListener<string>(MsgEventType.CAPTURE_PET, CapturePetCallback);
            EventCenter.RemoveListener<string>(MsgEventType.MATCHP_PET, MatchPetCallback);
            EventCenter.RemoveListener<string>(MsgEventType.GET_MATCH_COUNT, GetMatchCountCallback);
            if (realityCam != null)
                Destroy(this.realityCam);
            if (viewCamera != null)
                Destroy(this.viewCamera);
            if (getFaceDataFromAndroid != null)
                Destroy(this.getFaceDataFromAndroid);
            Debug.Log("OnExit");
        }

        IEnumerator StartCoroutineWait(float sec, Action onEvent)
        {
            yield return new WaitForSeconds(sec);
            if (onEvent != null)
                onEvent();
        }


        /// <summary>
        /// Update检测脸是否在指定位置
        /// </summary>
        private void CheckFacePos()
        {
            if (InnerRect())
            {
                getFaceDataFromAndroid.onFaceUpdate -= CheckFacePos;
                //PlayOnceAudioClip(this.detectorSucceedAudio);
                DetectorSuccess();
            }
        }

        /// <summary>
        /// 检测脸部位置 如果在某个区域内则返回true
        /// </summary>
        private bool InnerRect()
        {
            //print(getFaceDataFromAndroid.GetFacePointPos(0)+" "+Vector2.Distance(getFaceDataFromAndroid.GetFacePointPos(0), new Vector2(170, 315)));
            //print(getFaceDataFromAndroid.GetFacePointPos(2)+" "+Vector2.Distance(getFaceDataFromAndroid.GetFacePointPos(2), new Vector2(315, 305)));
            if (Vector2.Distance(getFaceDataFromAndroid.GetFacePointPos(0), new Vector2(170, 315)) < 25
                && Vector2.Distance(getFaceDataFromAndroid.GetFacePointPos(2), new Vector2(315, 305)) < 25)
            {
                if (index > 15)
                    return true;
                else
                { index++; return false; }
            }
            else
            {
                index = 0;
                return false;
            }
        }
        int index = 0;
        private void DetectorSuccess()
        {
            try
            {
                DetectorUI.Instance.ShowCircle(true);
                ParticleSystem ps = Instantiate(successPs);
                ps.transform.position = getFaceDataFromAndroid.WorldMouthPos + new Vector3(0, 0, -10);
                ps.Play();
                Destroy(ps.gameObject, 3);
                //UploadImageToMatchPet.instance.UploadImage(CameraHandler.instance.uploadTexture.EncodeToJPG());
                UploadIconToCS.Upload(Player.instance.GetPlayerInfo().userId,
                    CameraHandler.instance.uploadTexture.EncodeToJPG(),
                    240,
                    UploadCallback);
            }
            catch (Exception e)
            {
                Debug.Log(e.Message);
                NWarningManager.Instance.OpenDialogPanel("人脸检测异常", delegate
                {
                    OnExit();
                    SceneLoadManager.Instance.LoadSceneAsync("GameMain");
                });
            }
        }
        void UploadCallback(string imgUrl)
        {
            JsonData data = new JsonData();
            data["url"] = imgUrl;
            ND.ARGame.Net.NetManager.instance.Request(MsgEventType.MATCHP_PET, data.ToJson());
        }

        public void PlayOnceAudioClip(AudioClip clip)
        {
            if (clip == null)
            {
                return;

            }
            if (audioSourceOnce == null)
            {
                audioSourceOnce = FindObjectOfType<AudioSource>();
                if (audioSourceOnce == null)
                {
                    audioSourceOnce = this.gameObject.AddComponent<AudioSource>();
                }
            }
            audioSourceOnce.Stop();
            audioSourceOnce.clip = clip;
            audioSourceOnce.Play();
        }
        public void PlayOnceAudioClip(AudioClip[] clip)
        {
            if (clip.Length < 0)
            {
                return;

            }

            if (audioSourceOnce == null)
            {
                audioSourceOnce = FindObjectOfType<AudioSource>();
                if (audioSourceOnce == null)
                {
                    audioSourceOnce = this.gameObject.AddComponent<AudioSource>();
                }
            }

            foreach (var item in clip)
            {
                audioSourceOnce.PlayOneShot(item);
            }
        }




        //byte[] BeforImgPost(Texture2D texture,float angle) {
        //    Texture2D temp = Texture2D.whiteTexture;
        //    int width = texture.width;
        //    int height = texture.height;
        //    if (angle == 270)
        //    {
        //        temp = new Texture2D(height, width, TextureFormat.RGB24, false);
        //        for (int i = 0; i < width; i++)
        //        {
        //            for (int j = 0; j < height; j++)
        //            {
        //                temp.SetPixel(height - j - 1, i, texture.GetPixel(i, j));
        //            }
        //        }
        //    }
        //    else if (angle == 90)
        //    {
        //        temp = new Texture2D(height, width, TextureFormat.RGB24, false);
        //        for (int i = 0; i < width; i++)
        //        {
        //            for (int j = 0; j < height; j++)
        //            {
        //                temp.SetPixel(j, width - i - 1, texture.GetPixel(i, j));
        //            }
        //        }

        //    }
        //    temp.Apply();
        //    return temp.EncodeToJPG();
        //}

    }
}