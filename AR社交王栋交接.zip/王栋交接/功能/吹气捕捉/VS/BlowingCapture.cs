﻿using DG.Tweening;
using ND.Events;
using ND.Game.BusinessFramework;
using ND.Game.GameLogic;
using ND.Game.UILogic;
using ND.Utils;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
namespace ND.Game.GameLogic
{
    public class BlowingCapture : AbstactCapture
    {
        private GameObject viewCamera;
        public BlowingCapture(GameObject currPet,
            GameObject viewCamera,
            float increment,
            Callback<bool> callback)
            : base(currPet, increment, callback)
        {
            DetectorUI.Instance.CloseAllUI(true);
            currPet.transform.localEulerAngles = new Vector3(0, 180, 0);
            currPet.transform.position = new Vector3(20f, -3.5f, 10f);
            currPet.transform.localScale = Vector3.one * 5;
            this.viewCamera = viewCamera;
        }

        public override void StartCapture()
        {
            DetectorUI.Instance.OpenCaptureUIForm("Capture/BlowingCaptureUI");
            BlowingCaptureUI.Instance.OnCaptureEnd = (bool arg) =>
            {
                this.viewCamera.SetActive(false);
                callback(arg);
            };
        }
    }
}
